<?php
declare(strict_types=1);

require_once __DIR__ . '/../common.php';
require_once __DIR__ . '/../schema.php';

function deenai_validate_dataset_type(string $type): bool {
    $allowed = ['quran', 'hadith', 'fiqh', 'aqeedah', 'fatwa', 'book', 'story', 'faq', 'dua', 'adhkar', 'asmaulhusna'];
    return in_array(strtolower($type), $allowed, true);
}

function deenai_validate_storage_type(string $type): bool {
    return in_array(strtolower($type), ['json', 'txt'], true);
}

try {
    $pdo = deenai_db();
    deenai_require_admin($pdo);
    deenai_ensure_schema($pdo);
    deenai_seed_default_datasets($pdo);

    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));

    if ($method === 'GET') {
        $st = $pdo->query("
            SELECT d.*,
                   (SELECT COUNT(*) FROM dataset_sections s WHERE s.dataset_id = d.id) AS section_count
            FROM datasets d
            ORDER BY d.created_at DESC, d.id DESC
        ");
        $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $sectionsByDataset = [];
        if ($rows) {
            $ids = array_map(static fn(array $r): int => (int)$r['id'], $rows);
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $ss = $pdo->prepare("
                SELECT id, dataset_id, section_title, start_marker, end_marker
                FROM dataset_sections
                WHERE dataset_id IN ($placeholders)
                ORDER BY id ASC
            ");
            $ss->execute($ids);
            foreach (($ss->fetchAll(PDO::FETCH_ASSOC) ?: []) as $sec) {
                $datasetId = (int)$sec['dataset_id'];
                $sectionsByDataset[$datasetId] ??= [];
                $sectionsByDataset[$datasetId][] = [
                    'id' => (int)$sec['id'],
                    'section_title' => (string)$sec['section_title'],
                    'start_marker' => (string)($sec['start_marker'] ?? ''),
                    'end_marker' => (string)($sec['end_marker'] ?? '')
                ];
            }
        }

        $out = array_map(static function(array $row) use ($sectionsByDataset): array {
            $id = (int)$row['id'];
            return [
                'id' => $id,
                'name' => (string)$row['name'],
                'type' => (string)$row['type'],
                'storage_type' => (string)$row['storage_type'],
                'file_path' => (string)$row['file_path'],
                'keywords' => (string)($row['keywords'] ?? ''),
                'description' => (string)($row['description'] ?? ''),
                'active' => (int)$row['active'] === 1,
                'created_at' => (string)$row['created_at'],
                'sections' => $sectionsByDataset[$id] ?? [],
                'section_count' => (int)($row['section_count'] ?? 0)
            ];
        }, $rows);

        deenai_json(200, ['status' => 'success', 'datasets' => $out]);
    }

    $data = deenai_require_post_json_with_csrf();
    $action = strtolower(trim((string)($data['action'] ?? 'save')));

    if ($action === 'delete') {
        $id = (int)($data['id'] ?? 0);
        if ($id <= 0) {
            deenai_json(400, ['status' => 'error', 'message' => 'Invalid dataset id']);
        }
        $st = $pdo->prepare('DELETE FROM datasets WHERE id = ?');
        $st->execute([$id]);
        deenai_json(200, ['status' => 'success', 'message' => 'Dataset deleted']);
    }

    if ($action === 'toggle') {
        $id = (int)($data['id'] ?? 0);
        $active = deenai_normalize_bool($data['active'] ?? true, true) ? 1 : 0;
        if ($id <= 0) {
            deenai_json(400, ['status' => 'error', 'message' => 'Invalid dataset id']);
        }
        $st = $pdo->prepare('UPDATE datasets SET active = ?, updated_at = NOW() WHERE id = ?');
        $st->execute([$active, $id]);
        deenai_json(200, ['status' => 'success', 'message' => 'Dataset status updated']);
    }

    $id = (int)($data['id'] ?? 0);
    $name = deenai_clean_text((string)($data['name'] ?? ''));
    $type = strtolower(deenai_clean_text((string)($data['type'] ?? '')));
    $storageType = strtolower(deenai_clean_text((string)($data['storage_type'] ?? 'json')));
    $filePath = trim((string)($data['file_path'] ?? ''));
    $keywords = deenai_clean_text((string)($data['keywords'] ?? ''));
    $description = trim((string)($data['description'] ?? ''));
    $active = deenai_normalize_bool($data['active'] ?? true, true) ? 1 : 0;
    $sections = is_array($data['sections'] ?? null) ? $data['sections'] : [];

    if ($name === '' || !deenai_validate_dataset_type($type) || !deenai_validate_storage_type($storageType) || $filePath === '') {
        deenai_json(400, ['status' => 'error', 'message' => 'Invalid dataset payload']);
    }

    // New admin-added datasets are centralized under datasets_import/<type>/...
    if ($id <= 0) {
        $normalizedPath = str_replace('\\', '/', $filePath);
        if (!str_starts_with($normalizedPath, 'datasets_import/')) {
            deenai_json(400, ['status' => 'error', 'message' => 'New datasets must use centralized datasets_import path']);
        }
    }

    if ($id > 0) {
        $st = $pdo->prepare("
            UPDATE datasets
            SET name = ?, type = ?, storage_type = ?, file_path = ?, keywords = ?, description = ?, active = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $st->execute([$name, $type, $storageType, $filePath, $keywords, $description, $active, $id]);
    } else {
        $st = $pdo->prepare("
            INSERT INTO datasets (name, type, storage_type, file_path, keywords, description, active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ");
        $st->execute([$name, $type, $storageType, $filePath, $keywords, $description, $active]);
        $id = (int)$pdo->lastInsertId();
    }

    $pdo->prepare('DELETE FROM dataset_sections WHERE dataset_id = ?')->execute([$id]);
    if (!empty($sections)) {
        $ins = $pdo->prepare("
            INSERT INTO dataset_sections (dataset_id, section_title, start_marker, end_marker, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        foreach ($sections as $section) {
            if (!is_array($section)) {
                continue;
            }
            $title = deenai_clean_text((string)($section['section_title'] ?? ''));
            $start = trim((string)($section['start_marker'] ?? ''));
            $end = trim((string)($section['end_marker'] ?? ''));
            if ($title === '') {
                continue;
            }
            $ins->execute([$id, $title, $start !== '' ? $start : null, $end !== '' ? $end : null]);
        }
    }

    deenai_json(200, ['status' => 'success', 'message' => 'Dataset saved', 'dataset_id' => $id]);
} catch (Throwable $e) {
    error_log('deenai admin datasets error: ' . $e->getMessage());
    deenai_json(500, ['status' => 'error', 'message' => 'Server error']);
}
