<?php
declare(strict_types=1);

require_once __DIR__ . '/../common.php';
require_once __DIR__ . '/../schema.php';

try {
    $pdo = deenai_db();
    deenai_require_admin($pdo);
    deenai_ensure_schema($pdo);

    $total = (int)$pdo->query('SELECT COUNT(*) FROM ai_query_logs')->fetchColumn();
    $todayUsers = (int)$pdo->query("
        SELECT COUNT(DISTINCT user_id)
        FROM ai_query_logs
        WHERE user_id IS NOT NULL
          AND DATE(created_at) = CURDATE()
    ")->fetchColumn();
    $avgMs = (float)$pdo->query("
        SELECT COALESCE(AVG(response_time_ms), 0)
        FROM ai_query_logs
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ")->fetchColumn();

    $banned = 0;
    try {
        $banned = (int)$pdo->query("
            SELECT COUNT(*)
            FROM user_moderation_status
            WHERE status = 'banned'
        ")->fetchColumn();
    } catch (Throwable) {
        $banned = 0;
    }

    $limit = max(10, min(100, (int)($_GET['limit'] ?? 40)));
    $st = $pdo->prepare("
        SELECT
            l.id, l.query_text, l.intent, l.status, l.response_time_ms, l.created_at,
            l.provider_used, l.cache_hit,
            u.username, u.full_name
        FROM ai_query_logs l
        LEFT JOIN users u ON u.id = l.user_id
        ORDER BY l.created_at DESC
        LIMIT ?
    ");
    $st->bindValue(1, $limit, PDO::PARAM_INT);
    $st->execute();
    $logs = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $items = array_map(static function(array $row): array {
        $name = trim((string)($row['full_name'] ?? ''));
        if ($name === '') {
            $name = trim((string)($row['username'] ?? 'Guest'));
        }
        return [
            'id' => (int)$row['id'],
            'time' => (string)$row['created_at'],
            'user' => $name !== '' ? $name : 'Guest',
            'type' => (string)($row['intent'] ?? 'unknown'),
            'query' => (string)$row['query_text'],
            'status' => (string)$row['status'],
            'responseTime' => ((int)$row['response_time_ms']) . 'ms',
            'provider' => (string)($row['provider_used'] ?? ''),
            'cache_hit' => (int)($row['cache_hit'] ?? 0) === 1
        ];
    }, $logs);

    deenai_json(200, [
        'status' => 'success',
        'stats' => [
            'totalResponses' => $total,
            'activeUsersToday' => $todayUsers,
            'avgResponseMs' => (int)round($avgMs),
            'bannedUsers' => $banned
        ],
        'logs' => $items
    ]);
} catch (Throwable $e) {
    error_log('deenai admin overview error: ' . $e->getMessage());
    deenai_json(500, ['status' => 'error', 'message' => 'Server error']);
}

