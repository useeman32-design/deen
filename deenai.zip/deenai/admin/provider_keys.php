<?php
declare(strict_types=1);

require_once __DIR__ . '/../common.php';
require_once __DIR__ . '/../schema.php';

function deenai_mask_key(string $key): string {
    $len = strlen($key);
    if ($len <= 8) {
        return str_repeat('*', $len);
    }
    return substr($key, 0, 4) . str_repeat('*', max(0, $len - 8)) . substr($key, -4);
}

try {
    $pdo = deenai_db();
    deenai_require_admin($pdo);
    deenai_ensure_schema($pdo);

    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if ($method === 'GET') {
        $rows = deenai_get_provider_config($pdo);
        $providers = ['groq', 'gemini', 'openrouter', 'huggingface'];
        $out = [];
        foreach ($providers as $provider) {
            $cfg = $rows[$provider] ?? ['api_key' => '', 'model_name' => '', 'active' => false];
            $out[] = [
                'provider_name' => $provider,
                'has_key' => trim((string)$cfg['api_key']) !== '',
                'api_key_masked' => trim((string)$cfg['api_key']) !== '' ? deenai_mask_key((string)$cfg['api_key']) : '',
                'model_name' => (string)($cfg['model_name'] ?? ''),
                'active' => !empty($cfg['active'])
            ];
        }
        deenai_json(200, ['status' => 'success', 'providers' => $out]);
    }

    $data = deenai_require_post_json_with_csrf();
    $provider = strtolower(trim((string)($data['provider_name'] ?? '')));
    $allowed = ['groq', 'gemini', 'openrouter', 'huggingface'];
    if (!in_array($provider, $allowed, true)) {
        deenai_json(400, ['status' => 'error', 'message' => 'Invalid provider']);
    }

    $action = strtolower(trim((string)($data['action'] ?? 'save')));
    if ($action === 'delete') {
        $st = $pdo->prepare('DELETE FROM ai_provider_keys WHERE provider_name = ?');
        $st->execute([$provider]);
        deenai_json(200, ['status' => 'success', 'message' => 'Provider key removed']);
    }

    $active = deenai_normalize_bool($data['active'] ?? true, true) ? 1 : 0;
    $model = trim((string)($data['model_name'] ?? ''));
    $apiKey = trim((string)($data['api_key'] ?? ''));

    if ($action === 'toggle') {
        $st = $pdo->prepare('UPDATE ai_provider_keys SET active = ?, updated_at = NOW() WHERE provider_name = ?');
        $st->execute([$active, $provider]);
        deenai_json(200, ['status' => 'success', 'message' => 'Provider status updated']);
    }

    if ($apiKey === '') {
        // Keep existing key if present, only update model/active.
        $st = $pdo->prepare("
            INSERT INTO ai_provider_keys (provider_name, api_key, model_name, active, created_at, updated_at)
            VALUES (?, '', ?, ?, NOW(), NOW())
            ON DUPLICATE KEY UPDATE
                model_name = VALUES(model_name),
                active = VALUES(active),
                updated_at = NOW()
        ");
        $st->execute([$provider, $model !== '' ? $model : null, $active]);
    } else {
        $st = $pdo->prepare("
            INSERT INTO ai_provider_keys (provider_name, api_key, model_name, active, created_at, updated_at)
            VALUES (?, ?, ?, ?, NOW(), NOW())
            ON DUPLICATE KEY UPDATE
                api_key = VALUES(api_key),
                model_name = VALUES(model_name),
                active = VALUES(active),
                updated_at = NOW()
        ");
        $st->execute([$provider, $apiKey, $model !== '' ? $model : null, $active]);
    }

    deenai_json(200, ['status' => 'success', 'message' => 'Provider configuration saved']);
} catch (Throwable $e) {
    error_log('deenai admin provider keys error: ' . $e->getMessage());
    deenai_json(500, ['status' => 'error', 'message' => 'Server error']);
}

