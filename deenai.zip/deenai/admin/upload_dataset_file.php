<?php
declare(strict_types=1);

require_once __DIR__ . '/../common.php';
require_once __DIR__ . '/../schema.php';

function deenai_upload_validate_dataset_type(string $type): bool {
    $allowed = ['quran', 'hadith', 'fiqh', 'aqeedah', 'fatwa', 'book', 'story', 'faq', 'dua', 'adhkar', 'asmaulhusna'];
    return in_array(strtolower($type), $allowed, true);
}

try {
    deenai_require_post_multipart_with_csrf();
    $pdo = deenai_db();
    deenai_require_admin($pdo);
    deenai_ensure_schema($pdo);

    if (empty($_FILES['dataset_file']) || !is_array($_FILES['dataset_file'])) {
        deenai_json(400, ['status' => 'error', 'message' => 'No file uploaded']);
    }
    $file = $_FILES['dataset_file'];
    $err = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($err !== UPLOAD_ERR_OK) {
        deenai_json(400, ['status' => 'error', 'message' => 'Upload failed']);
    }

    $datasetType = deenai_clean_text((string)($_POST['dataset_type'] ?? ''));
    $datasetType = strtolower($datasetType);
    if (!deenai_upload_validate_dataset_type($datasetType)) {
        deenai_json(400, ['status' => 'error', 'message' => 'Invalid dataset type']);
    }

    $name = (string)($file['name'] ?? 'dataset');
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, ['json', 'txt'], true)) {
        deenai_json(400, ['status' => 'error', 'message' => 'Only JSON and TXT files are allowed']);
    }

    $targetDirRel = 'datasets_import/' . $datasetType;
    $targetDir = deenai_project_root() . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $targetDirRel);
    if (!is_dir($targetDir) && !mkdir($targetDir, 0775, true) && !is_dir($targetDir)) {
        deenai_json(500, ['status' => 'error', 'message' => 'Unable to create upload directory']);
    }

    $safeBase = preg_replace('/[^a-zA-Z0-9_\-]+/', '_', pathinfo($name, PATHINFO_FILENAME)) ?: 'dataset';
    $saveName = $safeBase . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $targetPath = $targetDir . DIRECTORY_SEPARATOR . $saveName;
    if (!move_uploaded_file((string)$file['tmp_name'], $targetPath)) {
        deenai_json(500, ['status' => 'error', 'message' => 'Failed to save uploaded file']);
    }

    deenai_json(200, [
        'status' => 'success',
        'message' => 'File uploaded',
        'file_path' => $targetDirRel . '/' . $saveName,
        'dataset_type' => $datasetType,
        'storage_type' => $ext === 'txt' ? 'txt' : 'json'
    ]);
} catch (Throwable $e) {
    error_log('deenai dataset upload error: ' . $e->getMessage());
    deenai_json(500, ['status' => 'error', 'message' => 'Server error']);
}
