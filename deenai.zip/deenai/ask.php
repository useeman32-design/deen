<?php
declare(strict_types=1);

require_once __DIR__ . '/common.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/intent.php';
require_once __DIR__ . '/retriever.php';
require_once __DIR__ . '/providers.php';

function deenai_out_of_scope_response(?array $classification = null, ?array $dataset = null, ?string $intent = null): array {
    return [
        'status' => 'success',
        'out_of_scope' => true,
        'message' => deenai_out_of_scope_message(),
        'classification' => $classification['label'] ?? null,
        'intent' => $intent,
        'dataset' => $dataset ? [
            'id' => (int)($dataset['id'] ?? 0),
            'name' => (string)($dataset['name'] ?? ''),
            'type' => (string)($dataset['type'] ?? '')
        ] : null,
        'sources' => [],
        'original_items' => [],
        'ai_explanation' => deenai_out_of_scope_message(),
        'provider_used' => null,
        'provider_model' => null,
        'cache_hit' => false
    ];
}

function deenai_pick_items_by_ids(array $items, array $ids): array {
    $map = [];
    foreach ($items as $item) {
        $cid = (int)($item['_cid'] ?? 0);
        if ($cid > 0) {
            $map[$cid] = $item;
        }
    }
    $out = [];
    foreach ($ids as $id) {
        $id = (int)$id;
        if (isset($map[$id])) {
            $out[] = $map[$id];
        }
    }
    return $out;
}

function deenai_fallback_ids_from_candidates(array $candidates, int $count): array {
    $count = max(1, min(10, $count));
    $ids = [];
    foreach ($candidates as $candidate) {
        $cid = (int)($candidate['_cid'] ?? 0);
        if ($cid <= 0) {
            continue;
        }
        $ids[] = $cid;
        if (count($ids) >= $count) {
            break;
        }
    }
    return $ids;
}

function deenai_apply_personal_safety_footer(string $text): string {
    $text = trim($text);
    $footer = "For your specific case, please consult a verified scholar for a personal ruling.";
    if ($text === '') {
        return $footer;
    }
    if (!str_contains(deenai_lower($text), 'consult')) {
        $text .= "\n\n" . $footer;
    }
    return $text;
}

function deenai_normalize_context_lines(mixed $value, int $max = 4): array {
    if (!is_array($value)) {
        return [];
    }
    $out = [];
    foreach ($value as $line) {
        if (!is_string($line)) {
            continue;
        }
        $line = deenai_clean_text($line);
        if ($line === '') {
            continue;
        }
        if (deenai_strlen($line) > 220) {
            $line = deenai_substr($line, 0, 220);
        }
        $out[] = $line;
        if (count($out) >= $max) {
            break;
        }
    }
    return $out;
}

function deenai_question_is_ambiguous_followup(string $question): bool {
    $q = deenai_lower(deenai_clean_text($question));
    if ($q === '') {
        return false;
    }
    // Only treat as follow-up when wording is explicitly referential.
    if (preg_match('/^(another|more|again|next|same|that|this|it|also|and another)\b/u', $q) === 1) {
        return true;
    }
    // Very short fragments with pronouns are likely follow-ups.
    if (deenai_strlen($q) <= 12 && preg_match('/\b(that|this|it)\b/u', $q) === 1) {
        return true;
    }
    return false;
}

function deenai_is_topic_explicit_question(string $question): bool {
    $q = deenai_lower(deenai_clean_text($question));
    if ($q === '') {
        return false;
    }
    $topicSignals = [
        'quran', 'surah', 'ayah', 'verse', 'hadith', 'dua', 'adhkar', 'azkar', 'dhikr',
        'allah', 'prophet', 'muhammad', 'zakat', 'salah', 'fast', 'ramadan', 'hajj',
        'halal', 'haram', 'fiqh', 'fatwa', 'aqeedah', 'name'
    ];
    foreach ($topicSignals as $signal) {
        if (str_contains($q, $signal)) {
            return true;
        }
    }
    return false;
}

function deenai_context_line_looks_like_user_question(string $line): bool {
    $line = deenai_clean_text($line);
    if ($line === '') {
        return false;
    }
    if (deenai_strlen($line) > 180) {
        return false;
    }
    $lower = deenai_lower($line);
    if (preg_match('/\?$/u', $line) === 1) {
        return true;
    }
    if (preg_match('/^(what|when|why|how|who|where|is|are|can|could|do|does|did|give|tell|show)\b/u', $lower) === 1) {
        return true;
    }
    return false;
}

function deenai_build_effective_question(string $question, array $contextLines): string {
    $base = deenai_clean_text($question);
    if ($base === '' || empty($contextLines)) {
        return $base;
    }
    if (!deenai_question_is_ambiguous_followup($base)) {
        return $base;
    }
    if (deenai_is_topic_explicit_question($base)) {
        return $base;
    }
    $lastContext = end($contextLines);
    if (!is_string($lastContext) || trim($lastContext) === '') {
        return $base;
    }
    if (!deenai_context_line_looks_like_user_question($lastContext)) {
        return $base;
    }
    return deenai_clean_text($lastContext . ' | Follow-up: ' . $base);
}

function deenai_top_confidence_score(array $items): int {
    if (empty($items)) {
        return 0;
    }
    return (int)($items[0]['confidence_score'] ?? 0);
}

function deenai_is_related_scholar_match(array $dataset, array $items): bool {
    $type = deenai_lower((string)($dataset['type'] ?? ''));
    if (!in_array($type, ['fatwa', 'fiqh', 'faq'], true)) {
        return false;
    }
    $top = deenai_top_confidence_score($items);
    return $top > 0 && $top < 18;
}

function deenai_related_summary_from_item(array $item): string {
    $question = deenai_clean_text((string)($item['question'] ?? ''));
    $answer = deenai_clean_text((string)($item['english'] ?? $item['text'] ?? ''));
    if (deenai_strlen($answer) > 520) {
        $answer = deenai_substr($answer, 0, 520) . '...';
    }
    $prefix = 'Your exact question is outside my current dataset scope, but I found a related scholar-answered question.';
    $body = $question !== '' ? ("Related question: " . $question . "\n\nSummary: " . $answer) : ("Summary: " . $answer);
    return trim($prefix . "\n\n" . $body);
}

function deenai_should_skip_llm_ranking(array $intentCtx, array $candidates): bool {
    if (empty($candidates)) {
        return true;
    }
    if (!empty($intentCtx['explicit_type_lock'])) {
        return true;
    }
    if (count($candidates) <= 3) {
        return true;
    }
    return false;
}

function deenai_locked_type_low_confidence(array $intentCtx, array $dataset, array $items): bool {
    if (empty($intentCtx['explicit_type_lock']) || empty($items)) {
        return false;
    }
    $type = deenai_lower((string)($dataset['type'] ?? ''));
    if (!in_array($type, ['quran', 'hadith', 'dua', 'adhkar', 'asmaulhusna'], true)) {
        return false;
    }
    $top = (int)($items[0]['confidence_score'] ?? 0);
    if ($type === 'quran') {
        return $top > 0 && $top < 2;
    }
    return $top > 0 && $top < 3;
}

function deenai_apply_source_intro_style(string $text, array $items): string {
    $text = trim($text);
    if ($text === '' || empty($items)) {
        return $text;
    }
    if (str_contains(deenai_lower($text), deenai_lower(deenai_out_of_scope_message()))) {
        return $text;
    }
    $firstType = deenai_lower((string)($items[0]['type'] ?? ''));
    $clean = preg_replace('/^\s*(according to|based on|from this|this (ayah|hadith) (shows|means)|the verse says)\b[^:]*:\s*/iu', '', $text) ?? $text;
    $clean = trim($clean);

    if ($firstType === 'quran_ayah' || $firstType === 'quran_count') {
        if (!preg_match('/^allah\s+(says|mentions)/iu', $clean)) {
            return 'Allah says: ' . $clean;
        }
        return $clean;
    }
    if ($firstType === 'hadith') {
        if (!preg_match('/^prophet\s+muhammad/iu', $clean)) {
            return 'Prophet Muhammad (peace be upon him) said: ' . $clean;
        }
        return $clean;
    }
    return $clean;
}

function deenai_active_dataset_types(PDO $pdo): array {
    $types = [];
    $st = $pdo->query("SELECT DISTINCT type FROM datasets WHERE active = 1");
    $rows = $st ? ($st->fetchAll(PDO::FETCH_ASSOC) ?: []) : [];
    foreach ($rows as $row) {
        $type = deenai_lower(trim((string)($row['type'] ?? '')));
        if ($type === '') {
            continue;
        }
        $types[] = $type;
    }
    if (!in_array('quran', $types, true)) {
        $types[] = 'quran';
    }
    if (!in_array('hadith', $types, true)) {
        $types[] = 'hadith';
    }
    return array_values(array_unique($types, SORT_STRING));
}

function deenai_router_allowed_categories(array $activeTypes): array {
    $base = [
        'quran',
        'hadith',
        'dua',
        'adhkar',
        '99names',
        'general_islamic_guidance',
        'casual_chat',
        'out_of_scope',
        'combinational_response'
    ];
    foreach ($activeTypes as $type) {
        $t = deenai_lower((string)$type);
        if ($t === 'asmaulhusna') {
            $base[] = '99names';
            $base[] = 'asmaulhusna';
            continue;
        }
        if ($t !== '') {
            $base[] = $t;
        }
    }
    return array_values(array_unique($base, SORT_STRING));
}

function deenai_internal_router_category(string $category): string {
    $c = deenai_lower(deenai_clean_text($category));
    return match ($c) {
        '99names', '99_names', 'asma ul husna', 'asmaul_husna' => 'asmaulhusna',
        default => $c
    };
}

function deenai_dataset_type_for_router_category(string $category): ?string {
    $c = deenai_internal_router_category($category);
    return match ($c) {
        'quran' => 'quran',
        'hadith' => 'hadith',
        'dua' => 'dua',
        'adhkar' => 'adhkar',
        'asmaulhusna', '99names' => 'asmaulhusna',
        'fiqh' => 'fiqh',
        'fatwa' => 'fatwa',
        'aqeedah' => 'aqeedah',
        'faq' => 'faq',
        'book' => null,
        'story' => null,
        default => null
    };
}

function deenai_intent_to_router_category(?array $intentCtx): string {
    if (!is_array($intentCtx)) {
        return 'general_islamic_guidance';
    }
    $intent = deenai_lower((string)($intentCtx['intent'] ?? ''));
    return match ($intent) {
        'quran_ayah_lookup', 'quran_ayah_count' => 'quran',
        'hadith_lookup' => 'hadith',
        'dua_adhkar_lookup' => 'dua',
        'asmaulhusna_lookup' => 'asmaulhusna',
        'fiqh_explanation' => 'fiqh',
        'aqeedah_explanation' => 'aqeedah',
        'fatwa_lookup' => 'fatwa',
        'faq_lookup' => 'faq',
        'book_story_lookup' => 'story',
        default => 'general_islamic_guidance'
    };
}

function deenai_try_explicit_category_override(string $question): ?string {
    $lock = deenai_detect_explicit_type_lock($question);
    if (!is_array($lock) || empty($lock['types']) || !is_array($lock['types'])) {
        return null;
    }
    $types = array_values(array_unique(array_map(static fn($x) => deenai_lower((string)$x), $lock['types']), SORT_STRING));
    if (empty($types)) {
        return null;
    }
    if (count($types) > 1) {
        if (in_array('quran', $types, true) && in_array('hadith', $types, true)) {
            return 'combinational_response';
        }
        return $types[0];
    }
    return $types[0];
}

function deenai_is_strict_casual_chat(string $question): bool {
    $q = deenai_lower(deenai_clean_text($question));
    if ($q === '') {
        return false;
    }
    if (deenai_conversation_gate_response($question) !== null) {
        return true;
    }
    if (deenai_is_topic_explicit_question($question)) {
        return false;
    }
    $patterns = [
        '/\b(how are you|how r u|what\'?s up|wassup|sup)\b/u',
        '/\b(can we chat|lets chat|let us chat|just want to chat|talk to me)\b/u',
        '/\b(i am bored|im bored|bored)\b/u',
        '/\b(who are you|introduce yourself)\b/u',
        '/\b(good afternoon|good night|good noon)\b/u',
        '/\b(ok|okay|alright|sure|cool|nice|great)\b/u',
        '/\b(bye|goodbye|see you)\b/u'
    ];
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $q) === 1 && deenai_strlen($q) <= 80) {
            return true;
        }
    }
    return false;
}

function deenai_candidate_match_score(array $item, array $tokens, string $question, string $routerCategory): int {
    // Cap raw retriever confidence so lexical relevance remains dominant.
    $score = min(12, max(0, (int)($item['confidence_score'] ?? 0)));
    $hay = deenai_lower(trim(
        (string)($item['english'] ?? '') . ' '
        . (string)($item['text'] ?? '') . ' '
        . (string)($item['reference'] ?? '') . ' '
        . (string)($item['arabic'] ?? '')
    ));
    $q = deenai_lower(deenai_clean_text($question));
    if ($q !== '' && str_contains($hay, $q)) {
        $score += 8;
    }
    $matchedTokens = 0;
    foreach ($tokens as $tok) {
        $needle = deenai_lower((string)$tok);
        if ($needle === '' || deenai_strlen($needle) < 2) {
            continue;
        }
        if (str_contains($hay, $needle)) {
            $score += 3;
            $matchedTokens++;
        }
    }
    if ($matchedTokens === 0) {
        $score -= 6;
    }

    $expectedType = deenai_dataset_type_for_router_category($routerCategory);
    $datasetType = deenai_lower((string)($item['_dataset_type'] ?? ''));
    if ($expectedType !== null && $datasetType !== '') {
        if ($datasetType === $expectedType) {
            $score += 10;
        } elseif ($routerCategory !== 'combinational_response' && $routerCategory !== 'general_islamic_guidance') {
            $score -= 10;
        }
    }
    return $score;
}

function deenai_category_to_dataset_types(string $category, array $activeTypes): array {
    $category = deenai_internal_router_category($category);
    $activeTypes = array_values(array_unique(array_map(static fn($x) => deenai_lower((string)$x), $activeTypes), SORT_STRING));

    if ($category === 'casual_chat' || $category === 'out_of_scope') {
        return [];
    }
    if ($category === 'quran' || $category === 'hadith' || $category === 'dua' || $category === 'adhkar' || $category === 'asmaulhusna') {
        return [$category];
    }
    if ($category === 'book' || $category === 'story') {
        $out = [];
        foreach (['story', 'book'] as $type) {
            if (in_array($type, $activeTypes, true)) {
                $out[] = $type;
            }
        }
        return !empty($out) ? $out : ['story', 'book'];
    }
    if ($category === 'general_islamic_guidance') {
        return !empty($activeTypes)
            ? $activeTypes
            : ['faq', 'fiqh', 'fatwa', 'quran', 'hadith', 'dua', 'adhkar'];
    }
    if ($category === 'combinational_response') {
        $combo = ['quran', 'hadith'];
        foreach ($activeTypes as $type) {
            if (!in_array($type, $combo, true)) {
                $combo[] = $type;
            }
        }
        return $combo;
    }
    if (in_array($category, $activeTypes, true)) {
        return [$category];
    }
    return !empty($activeTypes) ? $activeTypes : ['quran', 'hadith', 'faq'];
}

function deenai_is_personal_verdict_question(string $question): bool {
    $q = deenai_lower(deenai_clean_text($question));
    if ($q === '') {
        return false;
    }
    $signals = [
        'am i going to hell',
        'is my fast broken',
        'is my fasting broken',
        'is this a sin for me',
        'is this a sin',
        'will allah punish me',
        'will i be punished',
        'is my prayer valid',
        'is this halal for me',
        'is this haram for me'
    ];
    foreach ($signals as $signal) {
        if (str_contains($q, $signal)) {
            return true;
        }
    }
    return preg_match('/\b(is|am|will|does|did|can)\b.{0,50}\b(sin|haram|halal|valid|broken|punish|hell)\b/u', $q) === 1;
}

function deenai_casual_chat_reply(string $question): string {
    $gate = deenai_conversation_gate_response($question);
    if (is_array($gate) && trim((string)($gate['reply'] ?? '')) !== '') {
        return trim((string)$gate['reply']);
    }
    $fallbacks = [
        'Assalamu alaikum. We can chat, and I can also answer Islamic questions from your local datasets.',
        'Wa alaikum assalam. I am here. You can chat with me or ask your next Islamic question.',
        'I am here with you. Ask anything from your DeenLink datasets whenever you are ready.'
    ];
    try {
        return (string)$fallbacks[random_int(0, count($fallbacks) - 1)];
    } catch (Throwable) {
        return (string)$fallbacks[0];
    }
}

function deenai_build_router_intent_ctx(string $question, array $types, string $category): array {
    $parsed = deenai_parse_surah_ayah($question);
    $tokens = deenai_keywords_from_text($question);
    $category = deenai_internal_router_category($category);
    $lowerQ = deenai_lower(deenai_clean_text($question));
    $intent = 'llm_router:' . $category;
    if ($category === 'quran') {
        $intent = (preg_match('/\b(ayah count|verse count|how many ayah|how many verses|number of verses)\b/u', $lowerQ) === 1)
            ? 'quran_ayah_count'
            : 'quran_ayah_lookup';
    } elseif ($category === 'hadith') {
        $intent = 'hadith_lookup';
    } elseif ($category === 'dua' || $category === 'adhkar') {
        $intent = 'dua_adhkar_lookup';
    } elseif ($category === 'asmaulhusna') {
        $intent = 'asmaulhusna_lookup';
    } elseif ($category === 'fiqh') {
        $intent = 'fiqh_explanation';
    } elseif ($category === 'fatwa') {
        $intent = 'fatwa_lookup';
    } elseif ($category === 'aqeedah') {
        $intent = 'aqeedah_explanation';
    } elseif ($category === 'faq') {
        $intent = 'faq_lookup';
    } elseif ($category === 'book' || $category === 'story') {
        $intent = 'book_story_lookup';
    }

    return [
        'intent' => $intent,
        'types' => array_values(array_unique(array_map(static fn($x) => deenai_lower((string)$x), $types), SORT_STRING)),
        'tokens' => $tokens,
        'query' => deenai_normalize_query_text($question),
        'surah' => (int)($parsed['surah'] ?? 0),
        'ayah' => (int)($parsed['ayah'] ?? 0),
        'score' => 0,
        'classification' => $category,
        'explicit_type_lock' => in_array($category, ['quran', 'hadith', 'dua', 'adhkar', 'asmaulhusna'], true)
    ];
}

function deenai_collect_ranked_candidates(PDO $pdo, array $intentCtx, int $maxCandidates = 15, int $maxDatasets = 8): array {
    $maxCandidates = max(1, min(15, $maxCandidates));
    $maxDatasets = max(1, min(12, $maxDatasets));
    $rankedDatasets = deenai_select_ranked_datasets($pdo, $intentCtx, $maxDatasets);
    if (empty($rankedDatasets)) {
        return ['datasets' => [], 'candidates' => []];
    }

    $candidates = [];
    $routerCategory = deenai_internal_router_category((string)($intentCtx['classification'] ?? ''));
    $tokens = is_array($intentCtx['tokens'] ?? null) ? (array)$intentCtx['tokens'] : [];
    $query = (string)($intentCtx['query'] ?? '');
    foreach ($rankedDatasets as $dataset) {
        $remaining = $maxCandidates - count($candidates);
        if ($remaining <= 0) {
            break;
        }
        $perDatasetLimit = max(1, min(8, $remaining));
        $items = deenai_retrieve_content($pdo, $dataset, $intentCtx, $perDatasetLimit);
        if (empty($items)) {
            continue;
        }
        foreach ($items as $item) {
            $item['_dataset_id'] = (int)($dataset['id'] ?? 0);
            $item['_dataset_name'] = (string)($dataset['name'] ?? '');
            $item['_dataset_type'] = (string)($dataset['type'] ?? '');
            $item['_dataset_storage'] = (string)($dataset['storage_type'] ?? '');
            $item['_score'] = deenai_candidate_match_score($item, $tokens, $query, $routerCategory);
            if ($item['_score'] <= 0) {
                continue;
            }
            $candidates[] = $item;
            if (count($candidates) >= $maxCandidates) {
                break 2;
            }
        }
    }

    usort($candidates, static function (array $a, array $b): int {
        $cmp = ((int)($b['_score'] ?? 0)) <=> ((int)($a['_score'] ?? 0));
        if ($cmp !== 0) {
            return $cmp;
        }
        return strcmp((string)($a['_dataset_name'] ?? ''), (string)($b['_dataset_name'] ?? ''));
    });
    $candidates = array_slice($candidates, 0, $maxCandidates);
    foreach ($candidates as $i => &$candidate) {
        $candidate['_cid'] = $i + 1;
    }
    unset($candidate);

    return ['datasets' => $rankedDatasets, 'candidates' => $candidates];
}

function deenai_dataset_from_candidate(array $candidate): ?array {
    $id = (int)($candidate['_dataset_id'] ?? 0);
    if ($id <= 0) {
        return null;
    }
    return [
        'id' => $id,
        'name' => (string)($candidate['_dataset_name'] ?? ''),
        'type' => (string)($candidate['_dataset_type'] ?? ''),
        'storage_type' => (string)($candidate['_dataset_storage'] ?? 'json')
    ];
}

function deenai_trace_file_path(): string {
    return deenai_project_root()
        . DIRECTORY_SEPARATOR . 'storage'
        . DIRECTORY_SEPARATOR . 'deenai'
        . DIRECTORY_SEPARATOR . 'qa_history.json';
}

/**
 * Stores every question+response pair in local JSON history for quality audits.
 */
function deenai_store_qa_trace(?string $question, ?string $effectiveQuestion, array $response, int $httpStatus = 200): void {
    try {
        $path = deenai_trace_file_path();
        $dir = dirname($path);
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }

        $entry = [
            'timestamp' => gmdate('c'),
            'user_id' => deenai_current_user_id(),
            'http_status' => $httpStatus,
            'question' => deenai_clean_text((string)($question ?? '')),
            'effective_question' => deenai_clean_text((string)($effectiveQuestion ?? '')),
            'status' => (string)($response['status'] ?? ''),
            'classification' => isset($response['classification']) ? (string)$response['classification'] : null,
            'intent' => isset($response['intent']) ? (string)$response['intent'] : null,
            'out_of_scope' => !empty($response['out_of_scope']),
            'cache_hit' => !empty($response['cache_hit']),
            'dataset' => $response['dataset'] ?? null,
            'datasets_used' => $response['datasets_used'] ?? null,
            'debug_routing' => $response['debug_routing'] ?? null,
            'ai_explanation' => isset($response['ai_explanation']) ? (string)$response['ai_explanation'] : '',
            'response' => $response
        ];

        $fh = @fopen($path, 'c+');
        if (!is_resource($fh)) {
            return;
        }
        if (!flock($fh, LOCK_EX)) {
            fclose($fh);
            return;
        }

        rewind($fh);
        $raw = stream_get_contents($fh);
        $payload = json_decode(is_string($raw) ? $raw : '', true);
        if (!is_array($payload)) {
            $payload = ['entries' => []];
        }
        if (!isset($payload['entries']) || !is_array($payload['entries'])) {
            $payload['entries'] = [];
        }
        $payload['entries'][] = $entry;
        $payload['updated_at'] = gmdate('c');
        $payload['total'] = count($payload['entries']);

        $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (is_string($json)) {
            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, $json);
            fflush($fh);
        }
        flock($fh, LOCK_UN);
        fclose($fh);
    } catch (Throwable $e) {
        error_log('deenai trace log warning: ' . $e->getMessage());
    }
}

function deenai_emit_response(?string $question, ?string $effectiveQuestion, int $httpStatus, array $response): void {
    deenai_store_qa_trace($question, $effectiveQuestion, $response, $httpStatus);
    deenai_json($httpStatus, $response);
}

function deenai_is_date_query(string $question): bool {
    $q = deenai_lower(deenai_clean_text($question));
    if ($q === '') {
        return false;
    }
    $hasWhen = preg_match('/\b(today|current|now)\b/u', $q) === 1;
    $hasDateWord = preg_match('/\b(date|hijri|hijrah|islamic date|gregorian)\b/u', $q) === 1;
    if ($hasWhen && $hasDateWord) {
        return true;
    }
    return preg_match('/\b(hijri date|islamic date|gregorian date)\b/u', $q) === 1;
}

function deenai_gregorian_to_jd(int $year, int $month, int $day): float {
    if ($month <= 2) {
        $year -= 1;
        $month += 12;
    }
    $a = (int)floor($year / 100);
    $b = 2 - $a + (int)floor($a / 4);
    return floor(365.25 * ($year + 4716)) + floor(30.6001 * ($month + 1)) + $day + $b - 1524.5;
}

function deenai_hijri_month_names(): array {
    return [
        'Muharram', 'Safar', "Rabi' al-Awwal", "Rabi' al-Thani",
        'Jumada al-Awwal', 'Jumada al-Thani', 'Rajab', "Sha'ban",
        'Ramadan', 'Shawwal', "Dhu al-Qadah", "Dhu al-Hijjah"
    ];
}

function deenai_hijri_year_start_jd(int $hijriYear): float {
    $hijraJd = 1948440.5;
    return $hijraJd + floor(($hijriYear - 1) * 354.36607);
}

function deenai_hijri_month_lengths(int $hijriYear): array {
    $lengths = [30, 29, 30, 29, 30, 29, 30, 29, 30, 29, 30, 29];
    $longYears = [2, 5, 7, 10, 13, 16, 18, 21, 24, 26, 29];
    $yearInCycle = $hijriYear % 30;
    if (in_array($yearInCycle, $longYears, true)) {
        $lengths[11] = 30;
    }
    return $lengths;
}

function deenai_current_hijri_date(): array {
    $now = new DateTimeImmutable('now');
    $year = (int)$now->format('Y');
    $month = (int)$now->format('n');
    $day = (int)$now->format('j');
    $jd = deenai_gregorian_to_jd($year, $month, $day);
    $hijraJd = 1948440.5;
    $daysSinceEpoch = $jd - $hijraJd;
    $hijriYear = (int)floor($daysSinceEpoch / 354.36607) + 1;
    $yearStart = deenai_hijri_year_start_jd($hijriYear);
    if ($jd < $yearStart) {
        $hijriYear--;
        $yearStart = deenai_hijri_year_start_jd($hijriYear);
    }
    $daysIntoYear = (int)floor($jd - $yearStart);
    $monthLengths = deenai_hijri_month_lengths($hijriYear);
    $monthDays = 0;
    $hijriMonth = 0;
    $hijriDay = 1;
    for ($i = 0; $i < 12; $i++) {
        $monthDays += $monthLengths[$i];
        if ($daysIntoYear < $monthDays) {
            $hijriMonth = $i;
            $hijriDay = $daysIntoYear - ($monthDays - $monthLengths[$i]) + 1;
            break;
        }
    }
    $months = deenai_hijri_month_names();
    return [
        'year' => $hijriYear,
        'month' => $hijriMonth + 1,
        'day' => $hijriDay,
        'month_name' => $months[$hijriMonth] ?? 'Muharram',
        'formatted' => $hijriDay . ' ' . ($months[$hijriMonth] ?? 'Muharram') . ' ' . $hijriYear . ' AH'
    ];
}

function deenai_build_date_answer(): string {
    $now = new DateTimeImmutable('now');
    $gregorian = $now->format('l, F j, Y');
    $hijri = deenai_current_hijri_date();
    return "Today's Gregorian date is {$gregorian}.\nToday's Hijri date is {$hijri['formatted']}.";
}

function deenai_is_prayer_times_query(string $question): bool {
    $q = deenai_lower(deenai_clean_text($question));
    if ($q === '') {
        return false;
    }
    return str_contains($q, 'prayer time')
        || str_contains($q, 'salah time')
        || str_contains($q, 'fajr time')
        || str_contains($q, 'dhuhr time')
        || str_contains($q, 'asr time')
        || str_contains($q, 'maghrib time')
        || str_contains($q, 'isha time')
        || (str_contains($q, 'next prayer') && str_contains($q, 'time'));
}

function deenai_prayer_city_map(): array {
    return [
        'lagos' => ['name' => 'Lagos', 'lat' => 6.5244, 'lng' => 3.3792],
        'abuja' => ['name' => 'Abuja', 'lat' => 9.0765, 'lng' => 7.3986],
        'kano' => ['name' => 'Kano', 'lat' => 12.0022, 'lng' => 8.5919],
        'kaduna' => ['name' => 'Kaduna', 'lat' => 10.5105, 'lng' => 7.4165],
        'mecca' => ['name' => 'Makkah', 'lat' => 21.4225, 'lng' => 39.8262],
        'makkah' => ['name' => 'Makkah', 'lat' => 21.4225, 'lng' => 39.8262],
        'medina' => ['name' => 'Madinah', 'lat' => 24.4686, 'lng' => 39.6142],
        'madinah' => ['name' => 'Madinah', 'lat' => 24.4686, 'lng' => 39.6142],
        'london' => ['name' => 'London', 'lat' => 51.5072, 'lng' => -0.1276],
        'new york' => ['name' => 'New York', 'lat' => 40.7128, 'lng' => -74.0060]
    ];
}

function deenai_pick_prayer_city(string $question): array {
    $q = deenai_lower(deenai_clean_text($question));
    $map = deenai_prayer_city_map();
    foreach ($map as $needle => $city) {
        if (str_contains($q, $needle)) {
            return $city;
        }
    }
    return $map['lagos'];
}

function deenai_http_get_json(string $url, int $timeoutSeconds = 15): ?array {
    $ch = curl_init($url);
    if ($ch === false) {
        return null;
    }
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => max(8, $timeoutSeconds),
        CURLOPT_HTTPHEADER => ['Accept: application/json']
    ]);
    $body = curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($body === false || $httpCode < 200 || $httpCode >= 300) {
        return null;
    }
    $decoded = json_decode((string)$body, true);
    return is_array($decoded) ? $decoded : null;
}

function deenai_fetch_today_prayer_times(array $city): ?array {
    $dateStr = (new DateTimeImmutable('now'))->format('Y-m-d');
    $lat = (float)($city['lat'] ?? 0.0);
    $lng = (float)($city['lng'] ?? 0.0);
    if ($lat === 0.0 && $lng === 0.0) {
        return null;
    }
    $url = 'https://api.aladhan.com/v1/timings/' . rawurlencode($dateStr)
        . '?latitude=' . rawurlencode((string)$lat)
        . '&longitude=' . rawurlencode((string)$lng)
        . '&method=3&school=0';
    $data = deenai_http_get_json($url, 18);
    if (!is_array($data) || (int)($data['code'] ?? 0) !== 200 || !isset($data['data']['timings'])) {
        return null;
    }
    $timings = (array)$data['data']['timings'];
    return [
        'Fajr' => (string)($timings['Fajr'] ?? ''),
        'Dhuhr' => (string)($timings['Dhuhr'] ?? ''),
        'Asr' => (string)($timings['Asr'] ?? ''),
        'Maghrib' => (string)($timings['Maghrib'] ?? ''),
        'Isha' => (string)($timings['Isha'] ?? '')
    ];
}

function deenai_build_prayer_times_answer(string $question): ?string {
    $city = deenai_pick_prayer_city($question);
    $times = deenai_fetch_today_prayer_times($city);
    if (!is_array($times)) {
        return null;
    }
    $cityName = (string)($city['name'] ?? 'your location');
    return "Today's prayer times for {$cityName}:\n"
        . "Fajr: {$times['Fajr']}\n"
        . "Dhuhr: {$times['Dhuhr']}\n"
        . "Asr: {$times['Asr']}\n"
        . "Maghrib: {$times['Maghrib']}\n"
        . "Isha: {$times['Isha']}";
}

function deenai_unescape_js_string(string $value): string {
    return stripcslashes($value);
}

function deenai_load_quiz_dataset(): array {
    static $cache = null;
    if (is_array($cache)) {
        return $cache;
    }
    $path = deenai_project_root() . DIRECTORY_SEPARATOR . 'learning' . DIRECTORY_SEPARATOR . 'quiz.html';
    if (!is_file($path)) {
        $cache = [];
        return $cache;
    }
    $raw = file_get_contents($path);
    if (!is_string($raw) || $raw === '') {
        $cache = [];
        return $cache;
    }

    $pattern = '/\{\s*question:\s*"((?:\\\\.|[^"\\\\])*)"\s*,\s*options:\s*\[([\s\S]*?)\]\s*,\s*correct:\s*(\d+)(?:\s*,\s*explanation:\s*"((?:\\\\.|[^"\\\\])*)")?/u';
    preg_match_all($pattern, $raw, $matches, PREG_SET_ORDER);
    $rows = [];
    foreach ($matches as $m) {
        $question = deenai_unescape_js_string((string)($m[1] ?? ''));
        $optionsRaw = (string)($m[2] ?? '');
        $correct = (int)($m[3] ?? 0);
        $explanation = deenai_unescape_js_string((string)($m[4] ?? ''));
        if ($question === '') {
            continue;
        }
        $options = [];
        if (preg_match_all('/"((?:\\\\.|[^"\\\\])*)"/u', $optionsRaw, $optMatch)) {
            foreach (($optMatch[1] ?? []) as $opt) {
                $options[] = deenai_unescape_js_string((string)$opt);
            }
        }
        $rows[] = [
            'question' => $question,
            'options' => $options,
            'correct' => $correct,
            'explanation' => $explanation
        ];
    }
    $cache = $rows;
    return $cache;
}

function deenai_quiz_match(string $question): ?array {
    $rows = deenai_load_quiz_dataset();
    if (empty($rows)) {
        return null;
    }
    $query = deenai_normalize_query_text($question);
    $queryLower = deenai_lower($query);
    $queryTokens = deenai_keywords_from_text($query);

    $best = null;
    $bestScore = 0;
    foreach ($rows as $row) {
        $qq = deenai_lower((string)$row['question']);
        $score = 0;
        if ($queryLower !== '' && (str_contains($qq, $queryLower) || str_contains($queryLower, $qq))) {
            $score += 12;
        }
        $rowTokens = deenai_keywords_from_text((string)$row['question']);
        $rowMap = array_fill_keys($rowTokens, true);
        foreach ($queryTokens as $tok) {
            if (isset($rowMap[$tok])) {
                $score += 3;
            }
        }
        if ($score > $bestScore) {
            $bestScore = $score;
            $best = $row;
        }
    }
    if (!is_array($best) || $bestScore < 9) {
        return null;
    }
    $best['_score'] = $bestScore;
    return $best;
}

function deenai_build_quiz_answer(string $question): ?string {
    $match = deenai_quiz_match($question);
    if (!is_array($match)) {
        return null;
    }
    $options = is_array($match['options'] ?? null) ? $match['options'] : [];
    $correctIdx = (int)($match['correct'] ?? 0);
    $correctText = $options[$correctIdx] ?? '';
    if (trim((string)$correctText) === '') {
        return null;
    }
    $explanation = deenai_clean_text((string)($match['explanation'] ?? ''));
    if (deenai_strlen($explanation) > 420) {
        $explanation = deenai_substr($explanation, 0, 420) . '...';
    }
    return "From DeenLink Quiz dataset:\n"
        . "Question: " . (string)$match['question'] . "\n"
        . "Answer: " . (string)$correctText
        . ($explanation !== '' ? ("\nExplanation: " . $explanation) : '');
}

function deenai_item_text_preview(array $item, int $maxLen = 320): string {
    $text = deenai_clean_text((string)($item['english'] ?? $item['text'] ?? ''));
    if ($text === '') {
        $text = deenai_clean_text((string)($item['arabic'] ?? ''));
    }
    if (deenai_strlen($text) > $maxLen) {
        $text = deenai_substr($text, 0, $maxLen) . '...';
    }
    return $text;
}

function deenai_build_structured_response(string $routerCategory, array $selectedItems, int $topCount): ?string {
    if (empty($selectedItems)) {
        return null;
    }
    $routerCategory = deenai_internal_router_category($routerCategory);
    $topCount = max(1, min(10, $topCount));

    if ($routerCategory === 'hadith') {
        $lines = [];
        $n = 0;
        foreach ($selectedItems as $item) {
            $txt = deenai_item_text_preview($item, 360);
            if ($txt === '') {
                continue;
            }
            $txt = preg_replace('/\bAllah says[:,]?\s*/iu', '', $txt) ?? $txt;
            $ref = deenai_clean_text((string)($item['reference'] ?? ''));
            $n++;
            $lines[] = $n . '. Prophet Muhammad (peace be upon him) said: ' . $txt . ($ref !== '' ? " ({$ref})" : '');
            if ($n >= $topCount) {
                break;
            }
        }
        return !empty($lines) ? implode("\n", $lines) : null;
    }

    if ($routerCategory === 'asmaulhusna') {
        $lines = [];
        $n = 0;
        foreach ($selectedItems as $item) {
            $txt = deenai_item_text_preview($item, 180);
            if ($txt === '') {
                continue;
            }
            $n++;
            $lines[] = $n . '. ' . $txt;
            if ($n >= $topCount) {
                break;
            }
        }
        if (empty($lines)) {
            return null;
        }
        return "Here are {$n} names of Allah from your dataset:\n" . implode("\n", $lines);
    }

    if ($routerCategory === 'dua' || $routerCategory === 'adhkar') {
        $lines = [];
        $n = 0;
        foreach ($selectedItems as $item) {
            $arabic = deenai_clean_text((string)($item['arabic'] ?? ''));
            $english = deenai_item_text_preview($item, 220);
            $ref = deenai_clean_text((string)($item['reference'] ?? ''));
            if ($english === '' && $arabic === '') {
                continue;
            }
            $n++;
            $entry = $n . '. ';
            if ($english !== '') {
                $entry .= $english;
            }
            if ($arabic !== '') {
                $entry .= ($english !== '' ? "\n   Arabic: " : '') . $arabic;
            }
            if ($ref !== '') {
                $entry .= "\n   Reference: {$ref}";
            }
            $lines[] = $entry;
            if ($n >= $topCount) {
                break;
            }
        }
        if (empty($lines)) {
            return null;
        }
        return "Recommended supplication(s):\n" . implode("\n", $lines);
    }

    return null;
}

$question = '';
$effectiveQuestion = '';

try {
    $start = microtime(true);
    $input = deenai_require_post_json_with_csrf();
    $question = deenai_normalize_query_text((string)($input['question'] ?? ''));
    if ($question === '') {
        deenai_emit_response($question, $effectiveQuestion, 400, ['status' => 'error', 'message' => 'Question is required']);
    }
    $contextLines = deenai_normalize_context_lines($input['context'] ?? []);
    $effectiveQuestion = deenai_build_effective_question($question, $contextLines);
    if ($effectiveQuestion === '') {
        $effectiveQuestion = $question;
    }

    $pdo = deenai_db();
    deenai_ensure_schema($pdo);
    deenai_seed_default_datasets($pdo);

    $userId = deenai_current_user_id();
    $normalizedQuery = deenai_lower($question);
    $effectiveNormalized = deenai_lower($effectiveQuestion);
    $providerConfig = deenai_get_provider_config($pdo);

    if (deenai_is_date_query($question)) {
        $duration = (int)round((microtime(true) - $start) * 1000);
        $answer = deenai_build_date_answer();
        $logId = deenai_log_query(
            $pdo,
            $userId,
            $question,
            $normalizedQuery,
            'deterministic:date',
            null,
            'success',
            $duration,
            false,
            'local',
            0
        );
        deenai_emit_response($question, $effectiveQuestion, 200, [
            'status' => 'success',
            'out_of_scope' => false,
            'message' => '',
            'classification' => 'informational',
            'intent' => 'date_lookup',
            'dataset' => null,
            'sources' => [],
            'original_items' => [],
            'ai_explanation' => $answer,
            'provider_used' => 'local',
            'provider_model' => 'deterministic',
            'cache_hit' => false,
            'debug_routing' => [
                'category' => 'general_islamic_guidance',
                'reason' => 'deterministic_date_handler',
                'router_confidence' => null
            ],
            'query_log_id' => $logId
        ]);
    }

    if (deenai_is_prayer_times_query($question)) {
        $duration = (int)round((microtime(true) - $start) * 1000);
        $prayerAnswer = deenai_build_prayer_times_answer($question);
        if ($prayerAnswer === null) {
            $prayerAnswer = 'I could not fetch prayer times right now. Please ask again with a city name, for example: "Prayer times in Lagos today."';
        }
        $logId = deenai_log_query(
            $pdo,
            $userId,
            $question,
            $normalizedQuery,
            'deterministic:prayer_times',
            null,
            'success',
            $duration,
            false,
            'local',
            0
        );
        deenai_emit_response($question, $effectiveQuestion, 200, [
            'status' => 'success',
            'out_of_scope' => false,
            'message' => '',
            'classification' => 'informational',
            'intent' => 'prayer_times_lookup',
            'dataset' => null,
            'sources' => [],
            'original_items' => [],
            'ai_explanation' => $prayerAnswer,
            'provider_used' => 'local',
            'provider_model' => 'deterministic',
            'cache_hit' => false,
            'debug_routing' => [
                'category' => 'general_islamic_guidance',
                'reason' => 'deterministic_prayer_handler',
                'router_confidence' => null
            ],
            'query_log_id' => $logId
        ]);
    }

    if (deenai_is_strict_casual_chat($question)) {
        $duration = (int)round((microtime(true) - $start) * 1000);
        $reply = deenai_casual_chat_reply($question);
        $logId = deenai_log_query(
            $pdo,
            $userId,
            $question,
            $normalizedQuery,
            'casual_chat:deterministic',
            null,
            'success',
            $duration,
            false,
            null,
            0
        );
        deenai_emit_response($question, $effectiveQuestion, 200, [
            'status' => 'success',
            'out_of_scope' => false,
            'message' => '',
            'classification' => 'casual_chat',
            'intent' => 'casual_chat',
            'dataset' => null,
            'sources' => [],
            'original_items' => [],
            'ai_explanation' => $reply,
            'provider_used' => null,
            'provider_model' => null,
            'cache_hit' => false,
            'debug_routing' => [
                'category' => 'casual_chat',
                'reason' => 'deterministic_casual_gate',
                'router_confidence' => null
            ],
            'query_log_id' => $logId
        ]);
    }

    $quizAnswer = deenai_build_quiz_answer($question);
    if ($quizAnswer !== null) {
        $duration = (int)round((microtime(true) - $start) * 1000);
        $logId = deenai_log_query(
            $pdo,
            $userId,
            $question,
            $normalizedQuery,
            'deterministic:quiz_dataset',
            null,
            'success',
            $duration,
            false,
            'local',
            1
        );
        deenai_emit_response($question, $effectiveQuestion, 200, [
            'status' => 'success',
            'out_of_scope' => false,
            'message' => '',
            'classification' => 'informational',
            'intent' => 'quiz_dataset_lookup',
            'dataset' => [
                'id' => 0,
                'name' => 'Islamic Quiz Dataset',
                'type' => 'faq',
                'storage_type' => 'html'
            ],
            'sources' => [[
                'dataset_id' => 0,
                'dataset_name' => 'Islamic Quiz Dataset',
                'dataset_type' => 'faq',
                'reference' => 'learning/quiz.html'
            ]],
            'original_items' => [],
            'ai_explanation' => $quizAnswer,
            'provider_used' => 'local',
            'provider_model' => 'deterministic',
            'cache_hit' => false,
            'debug_routing' => [
                'category' => 'general_islamic_guidance',
                'reason' => 'deterministic_quiz_match',
                'router_confidence' => null
            ],
            'query_log_id' => $logId
        ]);
    }

    $activeTypes = deenai_active_dataset_types($pdo);
    $allowedCategories = deenai_router_allowed_categories($activeTypes);
    $personalVerdict = deenai_is_personal_verdict_question($effectiveQuestion);

    // Routing exists to avoid keyword-only misclassification and keep replies conversational.
    $router = deenai_route_question_with_fallback($providerConfig, $effectiveQuestion, $allowedCategories);
    $routerConfidence = (int)($router['confidence'] ?? 0);
    $routerCategory = deenai_internal_router_category((string)($router['category'] ?? ''));
    $routingReason = 'llm_router';

    if (!$router['ok']) {
        $routerCategory = 'general_islamic_guidance';
        $routingReason = 'router_failed_fallback';
    }
    if ($routerCategory === 'out_of_scope' && $routerConfidence < 70) {
        $routerCategory = 'general_islamic_guidance';
        $routingReason = 'router_low_confidence_out_of_scope_demote';
    }

    $explicitCategory = deenai_try_explicit_category_override($effectiveQuestion);
    if ($explicitCategory !== null && !in_array($routerCategory, ['casual_chat', 'out_of_scope'], true)) {
        $routerCategory = deenai_internal_router_category($explicitCategory);
        $routingReason = 'explicit_source_lock';
    } elseif ($routerConfidence < 45 && !in_array($routerCategory, ['casual_chat', 'out_of_scope'], true)) {
        // Low-confidence router outputs should not force a strict dataset.
        $routerCategory = 'general_islamic_guidance';
        $routingReason = 'low_confidence_router_demote_to_guidance';
    }
    if ($personalVerdict && !in_array($routerCategory, ['casual_chat', 'out_of_scope'], true)) {
        $routerCategory = 'general_islamic_guidance';
        $routingReason = 'personal_verdict_safety';
    }

    if ($routerCategory === 'casual_chat') {
        $duration = (int)round((microtime(true) - $start) * 1000);
        $reply = deenai_casual_chat_reply($question);
        $logId = deenai_log_query(
            $pdo,
            $userId,
            $question,
            $normalizedQuery,
            'casual_chat',
            null,
            'success',
            $duration,
            false,
            (string)($router['provider'] ?? null),
            0
        );
        foreach (($router['attempts'] ?? []) as $attempt) {
            deenai_log_provider_attempt(
                $pdo,
                $logId,
                (string)($attempt['provider'] ?? 'unknown'),
                isset($attempt['model']) ? (string)$attempt['model'] : null,
                (string)($attempt['status'] ?? 'failed'),
                (int)($attempt['latency_ms'] ?? 0),
                '[router] ' . (isset($attempt['error']) ? (string)$attempt['error'] : '')
            );
        }
        deenai_emit_response($question, $effectiveQuestion, 200, [
            'status' => 'success',
            'out_of_scope' => false,
            'message' => '',
            'classification' => 'casual_chat',
            'intent' => 'casual_chat',
            'dataset' => null,
            'sources' => [],
            'original_items' => [],
            'ai_explanation' => $reply,
            'provider_used' => (string)($router['provider'] ?? null),
            'provider_model' => (string)($router['model'] ?? null),
            'cache_hit' => false,
            'debug_routing' => [
                'category' => 'casual_chat',
                'reason' => $routingReason,
                'router_confidence' => $routerConfidence
            ],
            'query_log_id' => $logId
        ]);
    }

    if ($routerCategory === 'out_of_scope') {
        $duration = (int)round((microtime(true) - $start) * 1000);
        $logId = deenai_log_query(
            $pdo,
            $userId,
            $question,
            $normalizedQuery,
            'out_of_scope',
            null,
            'out_of_scope',
            $duration,
            false,
            (string)($router['provider'] ?? null),
            0
        );
        foreach (($router['attempts'] ?? []) as $attempt) {
            deenai_log_provider_attempt(
                $pdo,
                $logId,
                (string)($attempt['provider'] ?? 'unknown'),
                isset($attempt['model']) ? (string)$attempt['model'] : null,
                (string)($attempt['status'] ?? 'failed'),
                (int)($attempt['latency_ms'] ?? 0),
                '[router] ' . (isset($attempt['error']) ? (string)$attempt['error'] : '')
            );
        }
        $response = deenai_out_of_scope_response(['label' => 'out_of_scope'], null, 'out_of_scope');
        $response['debug_routing'] = [
            'category' => 'out_of_scope',
            'reason' => $routingReason,
            'router_confidence' => $routerConfidence
        ];
        $response['query_log_id'] = $logId;
        deenai_emit_response($question, $effectiveQuestion, 200, $response);
    }

    $types = deenai_category_to_dataset_types($routerCategory, $activeTypes);
    $classificationLabel = $personalVerdict ? 'personal_verdict' : (($routerCategory === 'dua' || $routerCategory === 'adhkar') ? 'guidance' : 'informational');
    $intentCtx = deenai_build_router_intent_ctx($effectiveQuestion, $types, $routerCategory);
    $intent = (string)($intentCtx['intent'] ?? 'llm_router');

    $requestedCount = deenai_requested_result_count($question, ['label' => $classificationLabel]);
    if (in_array($routerCategory, ['asmaulhusna', 'dua', 'adhkar', 'hadith'], true)) {
        $topCount = max(1, min(10, $requestedCount));
    } else {
        $topCount = max(1, min(3, $requestedCount));
    }
    $questionHash = hash('sha256', $effectiveNormalized);
    $cacheKey = hash('sha256', 'v6_router_deterministic|' . $questionHash . '|' . $routerCategory . '|' . $topCount);
    $cached = deenai_cache_get($pdo, $cacheKey);
    if (is_array($cached)) {
        $duration = (int)round((microtime(true) - $start) * 1000);
        $logId = deenai_log_query(
            $pdo,
            $userId,
            $question,
            $normalizedQuery,
            $intent,
            isset($cached['dataset']['id']) ? (int)$cached['dataset']['id'] : null,
            'success',
            $duration,
            true,
            (string)($cached['provider_used'] ?? ''),
            count($cached['original_items'] ?? [])
        );
        deenai_emit_response($question, $effectiveQuestion, 200, array_merge($cached, ['status' => 'success', 'cache_hit' => true, 'query_log_id' => $logId]));
    }

    // Candidate cap protects token usage and keeps selection deterministic.
    $retrieval = deenai_collect_ranked_candidates($pdo, $intentCtx, 15, 10);
    $rankedDatasets = (array)($retrieval['datasets'] ?? []);
    $candidates = (array)($retrieval['candidates'] ?? []);
    if ((empty($rankedDatasets) || empty($candidates)) && $routerCategory !== 'general_islamic_guidance') {
        $fallbackCategory = 'general_islamic_guidance';
        $fallbackTypes = deenai_category_to_dataset_types($fallbackCategory, $activeTypes);
        $fallbackIntentCtx = deenai_build_router_intent_ctx($effectiveQuestion, $fallbackTypes, $fallbackCategory);
        $retrievalFallback = deenai_collect_ranked_candidates($pdo, $fallbackIntentCtx, 15, 10);
        $fallbackDatasets = (array)($retrievalFallback['datasets'] ?? []);
        $fallbackCandidates = (array)($retrievalFallback['candidates'] ?? []);
        if (!empty($fallbackDatasets) && !empty($fallbackCandidates)) {
            $rankedDatasets = $fallbackDatasets;
            $candidates = $fallbackCandidates;
            $routerCategory = $fallbackCategory;
            $intentCtx = $fallbackIntentCtx;
            $intent = (string)($intentCtx['intent'] ?? 'llm_router');
            $routingReason = 'category_no_match_fallback_to_guidance';
        }
    }
    if (empty($rankedDatasets) || empty($candidates)) {
        $fallbackDataset = $rankedDatasets[0] ?? null;
        $duration = (int)round((microtime(true) - $start) * 1000);
        $logId = deenai_log_query(
            $pdo,
            $userId,
            $question,
            $normalizedQuery,
            $intent,
            is_array($fallbackDataset) ? (int)($fallbackDataset['id'] ?? 0) : null,
            'out_of_scope',
            $duration,
            false,
            (string)($router['provider'] ?? null),
            0
        );
        $response = deenai_out_of_scope_response(['label' => $classificationLabel], is_array($fallbackDataset) ? $fallbackDataset : null, $intent);
        $response['debug_routing'] = [
            'category' => $routerCategory,
            'reason' => $routingReason,
            'router_confidence' => $routerConfidence,
            'candidate_count' => count($candidates)
        ];
        $response['query_log_id'] = $logId;
        deenai_emit_response($question, $effectiveQuestion, 200, $response);
    }

    $selectorTop = max(1, min(3, $topCount));
    $skipSelector = in_array($routerCategory, ['asmaulhusna', 'dua', 'adhkar', 'hadith'], true) && $topCount > 3;
    $selector = ['ok' => false, 'category' => $routerCategory, 'ids' => [], 'provider' => null, 'model' => null, 'attempts' => []];
    if (!$skipSelector) {
        $selector = deenai_route_and_select_with_fallback(
            $providerConfig,
            $effectiveQuestion,
            $candidates,
            $allowedCategories,
            $routerCategory,
            $selectorTop
        );
    }
    $selectedCategory = deenai_internal_router_category((string)($selector['category'] ?? $routerCategory));
    if (
        $explicitCategory === null
        && !in_array($selectedCategory, ['casual_chat', 'out_of_scope'], true)
        && $selectedCategory !== ''
        && ($routerConfidence >= 45 || in_array($routerCategory, ['general_islamic_guidance', 'combinational_response'], true))
    ) {
        $routerCategory = $selectedCategory;
        $routingReason = 'selector_category_confirmed';
    }

    $rankedIds = !empty($selector['ok'])
        ? (array)($selector['ids'] ?? [])
        : deenai_fallback_ids_from_candidates($candidates, $topCount);
    $selectedItems = deenai_pick_items_by_ids($candidates, $rankedIds);
    if (empty($selectedItems)) {
        $selectedItems = deenai_pick_items_by_ids($candidates, deenai_fallback_ids_from_candidates($candidates, $topCount));
    }
    if (empty($selectedItems)) {
        $selectedItems = array_slice($candidates, 0, $topCount);
        $rankedIds = deenai_fallback_ids_from_candidates($selectedItems, $topCount);
    }

    $expectedType = deenai_dataset_type_for_router_category($routerCategory);
    if ($expectedType !== null && !in_array($routerCategory, ['general_islamic_guidance', 'combinational_response'], true)) {
        $strictSelected = array_values(array_filter($selectedItems, static function (array $item) use ($expectedType): bool {
            return deenai_lower((string)($item['_dataset_type'] ?? '')) === $expectedType;
        }));
        if (!empty($strictSelected)) {
            $selectedItems = $strictSelected;
            $rankedIds = array_values(array_map(static fn(array $x): int => (int)($x['_cid'] ?? 0), $selectedItems));
        } else {
            $strictCandidates = array_values(array_filter($candidates, static function (array $item) use ($expectedType): bool {
                return deenai_lower((string)($item['_dataset_type'] ?? '')) === $expectedType;
            }));
            if (!empty($strictCandidates)) {
                $selectedItems = array_slice($strictCandidates, 0, $topCount);
                $rankedIds = array_values(array_map(static fn(array $x): int => (int)($x['_cid'] ?? 0), $selectedItems));
                $routingReason = 'strict_type_enforced';
            }
        }
    }

    $topSelectedScore = !empty($selectedItems) ? (int)($selectedItems[0]['_score'] ?? $selectedItems[0]['confidence_score'] ?? 0) : 0;
    $minScore = in_array($routerCategory, ['general_islamic_guidance', 'combinational_response'], true) ? 8 : 12;
    if ($topSelectedScore < $minScore) {
        $duration = (int)round((microtime(true) - $start) * 1000);
        $logId = deenai_log_query(
            $pdo,
            $userId,
            $question,
            $normalizedQuery,
            $intent,
            null,
            'out_of_scope',
            $duration,
            false,
            (string)($selector['provider'] ?? $router['provider'] ?? null),
            count($selectedItems)
        );
        $response = deenai_out_of_scope_response(['label' => $classificationLabel], null, $intent);
        $response['message'] = 'I could not confidently match this question from the available dataset text. Please rephrase with more detail.';
        $response['ai_explanation'] = $response['message'];
        $response['debug_routing'] = [
            'category' => $routerCategory,
            'reason' => 'low_selected_score',
            'router_confidence' => $routerConfidence,
            'top_selected_score' => $topSelectedScore,
            'candidate_count' => count($candidates)
        ];
        $response['query_log_id'] = $logId;
        deenai_emit_response($question, $effectiveQuestion, 200, $response);
    }

    $primaryDataset = deenai_dataset_from_candidate($selectedItems[0] ?? []) ?? ($rankedDatasets[0] ?? null);
    $datasetId = is_array($primaryDataset) ? (int)($primaryDataset['id'] ?? 0) : 0;

    $aiExplanation = '';
    $providerUsed = null;
    $modelUsed = null;
    $status = 'success';
    $relatedScholarMatch = is_array($primaryDataset) ? deenai_is_related_scholar_match($primaryDataset, $selectedItems) : false;
    $explain = ['attempts' => []];

    $structuredReply = deenai_build_structured_response($routerCategory, $selectedItems, $topCount);
    if ($structuredReply !== null) {
        $aiExplanation = $structuredReply;
        $providerUsed = 'local';
        $modelUsed = 'deterministic';
    } elseif ($relatedScholarMatch) {
        $aiExplanation = deenai_related_summary_from_item($selectedItems[0] ?? []);
    } else {
        // Boxed summarization: only selected excerpts are sent to the LLM.
        $explain = deenai_generate_explanation_with_fallback(
            $providerConfig,
            $effectiveQuestion,
            $selectedItems,
            1400,
            [
                'personal_verdict' => $personalVerdict,
                'guidance_mode' => ($routerCategory === 'dua' || $routerCategory === 'adhkar' || $routerCategory === 'general_islamic_guidance')
            ]
        );
        if (!empty($explain['ok'])) {
            $aiExplanation = (string)($explain['explanation'] ?? '');
            $providerUsed = (string)($explain['provider'] ?? '');
            $modelUsed = (string)($explain['model'] ?? '');
        } else {
            $status = 'failed';
            $first = $selectedItems[0] ?? [];
            $fallbackText = trim((string)($first['english'] ?? $first['text'] ?? ''));
            $aiExplanation = $fallbackText !== '' ? $fallbackText : 'AI explanation is temporarily unavailable. Showing source excerpts only.';
        }
    }

    // Verdict protection exists to avoid personal rulings from AI.
    if ($personalVerdict) {
        $aiExplanation = deenai_apply_personal_safety_footer($aiExplanation);
    }
    if ($routerCategory === 'hadith' || (is_array($primaryDataset) && deenai_lower((string)($primaryDataset['type'] ?? '')) === 'hadith')) {
        $aiExplanation = preg_replace('/\bAllah says(?:\s+in\s+the\s+Qur\'?an)?[:,]?\s*/iu', '', $aiExplanation) ?? $aiExplanation;
        $aiExplanation = trim($aiExplanation);
        if ($aiExplanation !== '' && !preg_match('/^prophet\s+muhammad/iu', $aiExplanation)) {
            $aiExplanation = 'Prophet Muhammad (peace be upon him) said: ' . $aiExplanation;
        }
    }
    if (($routerCategory === 'dua' || $routerCategory === 'adhkar') && !str_contains(deenai_lower($aiExplanation), 'commonly recited')) {
        $aiExplanation = trim($aiExplanation) . "\n\nThese supplications are commonly recited during moments of need and remembrance.";
    }
    $aiExplanation = deenai_apply_source_intro_style($aiExplanation, $selectedItems);

    $sources = [];
    $datasetsUsed = [];
    foreach ($selectedItems as $item) {
        $srcDataset = deenai_dataset_from_candidate($item) ?? $primaryDataset;
        if (!is_array($srcDataset)) {
            continue;
        }
        $sources[] = [
            'dataset_id' => (int)($srcDataset['id'] ?? 0),
            'dataset_name' => (string)($srcDataset['name'] ?? ''),
            'dataset_type' => (string)($srcDataset['type'] ?? ''),
            'reference' => (string)($item['reference'] ?? '')
        ];
        $key = (string)($srcDataset['id'] ?? 0);
        if (!isset($datasetsUsed[$key])) {
            $datasetsUsed[$key] = [
                'id' => (int)($srcDataset['id'] ?? 0),
                'name' => (string)($srcDataset['name'] ?? ''),
                'type' => (string)($srcDataset['type'] ?? ''),
                'storage_type' => (string)($srcDataset['storage_type'] ?? 'json')
            ];
        }
    }

    $publicItems = array_map(static function (array $item): array {
        unset(
            $item['_cid'],
            $item['_score'],
            $item['_dataset_id'],
            $item['_dataset_name'],
            $item['_dataset_type'],
            $item['_dataset_storage']
        );
        return $item;
    }, $selectedItems);

    $response = [
        'status' => 'success',
        'out_of_scope' => false,
        'message' => '',
        'classification' => $classificationLabel,
        'intent' => $intent,
        'router_category' => $routerCategory,
        'dataset' => is_array($primaryDataset) ? [
            'id' => (int)($primaryDataset['id'] ?? 0),
            'name' => (string)($primaryDataset['name'] ?? ''),
            'type' => (string)($primaryDataset['type'] ?? ''),
            'storage_type' => (string)($primaryDataset['storage_type'] ?? 'json')
        ] : null,
        'datasets_used' => array_values($datasetsUsed),
        'sources' => $sources,
        'original_items' => array_values($publicItems),
        'ranked_candidate_ids' => array_values($rankedIds),
        'related_scholar_answer' => $relatedScholarMatch,
        'ai_explanation' => $aiExplanation,
        'provider_used' => $providerUsed ?: (string)($explain['provider'] ?? $selector['provider'] ?? $router['provider'] ?? ''),
        'provider_model' => $modelUsed ?: (string)($explain['model'] ?? $selector['model'] ?? $router['model'] ?? ''),
        'cache_hit' => false,
        'debug_routing' => [
            'router_raw_category' => (string)($router['category'] ?? ''),
            'router_confidence' => $routerConfidence,
            'final_category' => $routerCategory,
            'reason' => $routingReason,
            'candidate_count' => count($candidates),
            'selected_count' => count($selectedItems),
            'top_selected_score' => $topSelectedScore
        ]
    ];

    if ($status === 'success') {
        deenai_cache_set($pdo, $cacheKey, $response, 6 * 3600);
    }

    $duration = (int)round((microtime(true) - $start) * 1000);
    $logId = deenai_log_query(
        $pdo,
        $userId,
        $question,
        $normalizedQuery,
        $intent,
        $datasetId > 0 ? $datasetId : null,
        $status === 'success' ? 'success' : 'failed',
        $duration,
        false,
        $providerUsed ?: (string)($selector['provider'] ?? $router['provider'] ?? null),
        count($selectedItems)
    );

    foreach (($router['attempts'] ?? []) as $attempt) {
        deenai_log_provider_attempt(
            $pdo,
            $logId,
            (string)($attempt['provider'] ?? 'unknown'),
            isset($attempt['model']) ? (string)$attempt['model'] : null,
            (string)($attempt['status'] ?? 'failed'),
            (int)($attempt['latency_ms'] ?? 0),
            '[router] ' . (isset($attempt['error']) ? (string)$attempt['error'] : '')
        );
    }
    foreach (($selector['attempts'] ?? []) as $attempt) {
        deenai_log_provider_attempt(
            $pdo,
            $logId,
            (string)($attempt['provider'] ?? 'unknown'),
            isset($attempt['model']) ? (string)$attempt['model'] : null,
            (string)($attempt['status'] ?? 'failed'),
            (int)($attempt['latency_ms'] ?? 0),
            '[selector] ' . (isset($attempt['error']) ? (string)$attempt['error'] : '')
        );
    }
    foreach (($explain['attempts'] ?? []) as $attempt) {
        deenai_log_provider_attempt(
            $pdo,
            $logId,
            (string)($attempt['provider'] ?? 'unknown'),
            isset($attempt['model']) ? (string)$attempt['model'] : null,
            (string)($attempt['status'] ?? 'failed'),
            (int)($attempt['latency_ms'] ?? 0),
            '[explain] ' . (isset($attempt['error']) ? (string)$attempt['error'] : '')
        );
    }

    $response['query_log_id'] = $logId;
    deenai_emit_response($question, $effectiveQuestion, 200, $response);
} catch (Throwable $e) {
    error_log('deenai ask error: ' . $e->getMessage());
    deenai_emit_response($question, $effectiveQuestion, 500, ['status' => 'error', 'message' => 'Server error']);
}
