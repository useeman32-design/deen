<?php
declare(strict_types=1);

/**
 * DeenLink AI common helpers.
 * Anti-hallucination policy is enforced in ask.php by:
 * 1) deterministic intent selection,
 * 2) deterministic dataset selection,
 * 3) local dataset extraction only,
 * 4) no LLM call when extraction is empty.
 */

error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/csrf.php';
require_once __DIR__ . '/../admin/auth/common.php';

function deenai_json(int $statusCode, array $payload): void {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(
        $payload,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;
}

function deenai_db(): PDO {
    return DB::conn();
}

function deenai_project_root(): string {
    return dirname(__DIR__, 2);
}

function deenai_current_user_id(): int {
    if (!empty($_SESSION['logged_in']) && !empty($_SESSION['user_id'])) {
        return (int)$_SESSION['user_id'];
    }
    return 0;
}

function deenai_require_admin(PDO $pdo): int {
    // Prefer separate admin auth once configured.
    admin_auth_ensure_tables($pdo);
    if (admin_auth_has_any_admin($pdo)) {
        if (empty($_SESSION['admin_logged_in']) || empty($_SESSION['admin_user_id'])) {
            deenai_json(401, ['status' => 'error', 'message' => 'Not logged in']);
        }
        $adminId = (int)$_SESSION['admin_user_id'];
        $admin = admin_auth_get_admin_by_id($pdo, $adminId);
        if (!$admin || (int)($admin['is_active'] ?? 0) !== 1) {
            deenai_json(403, ['status' => 'error', 'message' => 'Forbidden']);
        }
        // DeenAI control lives in admin area; tie it to "settings" permission by default.
        $role = strtolower((string)($admin['role'] ?? 'viewer'));
        if ($role !== 'super_admin') {
            $perms = is_array($admin['permissions'] ?? null) ? $admin['permissions'] : [];
            if (!in_array('settings', $perms, true)) {
                deenai_json(403, ['status' => 'error', 'message' => 'Permission denied']);
            }
        }
        return $adminId;
    }

    // Legacy fallback (pre-bootstrap): old user admin sessions.
    $userId = deenai_current_user_id();
    if ($userId <= 0) {
        deenai_json(401, ['status' => 'error', 'message' => 'Not logged in']);
    }
    $st = $pdo->prepare('SELECT user_type, is_active FROM users WHERE id = ? LIMIT 1');
    $st->execute([$userId]);
    $me = $st->fetch(PDO::FETCH_ASSOC);
    if (!$me || (int)($me['is_active'] ?? 0) !== 1) {
        deenai_json(403, ['status' => 'error', 'message' => 'Forbidden']);
    }
    $isAdmin = strtolower((string)($me['user_type'] ?? '')) === 'admin';
    if (!$isAdmin) {
        deenai_json(403, ['status' => 'error', 'message' => 'Admin access required']);
    }
    return $userId;
}

function deenai_require_post_json_with_csrf(): array {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        deenai_json(405, ['status' => 'error', 'message' => 'Method not allowed']);
    }
    require_csrf();
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        deenai_json(400, ['status' => 'error', 'message' => 'Invalid JSON body']);
    }
    return $data;
}

function deenai_require_post_multipart_with_csrf(): void {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        deenai_json(405, ['status' => 'error', 'message' => 'Method not allowed']);
    }
    require_csrf();
}

function deenai_clean_text(string $value): string {
    $value = trim($value);
    $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
    return trim($value);
}

/**
 * Normalize user wording variants and common punctuation/typo forms.
 * This keeps intent detection deterministic while reducing keyword fragility.
 */
function deenai_normalize_query_text(string $value): string {
    $value = deenai_clean_text($value);
    if ($value === '') {
        return '';
    }
    $value = str_replace(
        ["’", "‘", "ʼ", "`", "´", "ʿ", "ʾ", "“", "”"],
        ["'", "'", "'", "'", "'", "", "", "\"", "\""],
        $value
    );

    $lower = deenai_lower($value);
    $replacements = [
        "/\bdu['` ]?a+a?\b/u" => 'dua',
        "/\bduas\b/u" => 'dua',
        "/\bsuplication\b/u" => 'supplication',
        "/\bsuppl?ication\b/u" => 'supplication',
        "/\bprayer before sleep\b/u" => 'dua before sleep',
        "/\bprayer for sleep\b/u" => 'dua before sleep',
        "/\bbefore bed\b/u" => 'before sleep',
        "/\bgoing bed\b/u" => 'going to bed',
        "/\badhkar\b/u" => 'adhkar',
        "/\bazkar\b/u" => 'adhkar',
        "/\bzikr\b/u" => 'dhikr',
        "/\baya\b/u" => 'ayah',
        "/\bayat\b/u" => 'ayah',
        "/\bverses?\b/u" => 'verse',
        "/\bsura\b/u" => 'surah',
        "/\bsoorah\b/u" => 'surah',
        "/\bhadeeth\b/u" => 'hadith',
        "/\bahaadith\b/u" => 'hadith',
        "/\bprophet mohammed\b/u" => 'prophet muhammad',
        "/\bprophet mohamed\b/u" => 'prophet muhammad',
        "/\bpbuh\b/u" => 'peace be upon him',
    ];
    foreach ($replacements as $pattern => $replacement) {
        $lower = preg_replace($pattern, $replacement, $lower) ?? $lower;
    }
    return deenai_clean_text($lower);
}

function deenai_lower(string $value): string {
    if (function_exists('mb_strtolower')) {
        return mb_strtolower($value, 'UTF-8');
    }
    return strtolower($value);
}

function deenai_keyword_alias_map(): array {
    return [
        'supplication' => ['dua', 'adhkar'],
        'invocation' => ['dua'],
        'prayer' => ['dua'],
        'remembrance' => ['dhikr', 'adhkar'],
        'dhikr' => ['adhkar'],
        'verse' => ['ayah', 'quran'],
        'ayah' => ['quran'],
        'aya' => ['ayah', 'quran'],
        'surah' => ['quran'],
        'sunnah' => ['hadith'],
        'narration' => ['hadith'],
        'names' => ['asmaulhusna'],
        'asmaulhusna' => ['names', 'allah'],
        'bedtime' => ['before', 'sleep', 'dua'],
        'sleep' => ['dua', 'night'],
        'morning' => ['adhkar'],
        'evening' => ['adhkar'],
    ];
}

function deenai_keyword_lexicon(): array {
    return [
        'quran', 'surah', 'ayah', 'verse', 'hadith', 'bukhari', 'muslim', 'tirmidhi',
        'abudawud', 'ibnmajah', 'nawawi', 'sunnah', 'dua', 'adhkar', 'dhikr',
        'supplication', 'asmaulhusna', 'names', 'allah', 'fiqh', 'fatwa', 'aqeedah',
        'halal', 'haram', 'wudu', 'salah', 'zakat', 'fasting', 'hajj', 'umrah',
        'tawbah', 'forgiveness', 'protection', 'fear', 'anxiety', 'patience',
        'morning', 'evening', 'sleep', 'bed', 'night', 'hell', 'paradise', 'sin',
        'valid', 'broken', 'reward', 'marriage', 'inheritance', 'prayer', 'remembrance'
    ];
}

function deenai_fuzzy_correct_token(string $token): string {
    $token = deenai_lower($token);
    if ($token === '' || deenai_strlen($token) < 3 || !function_exists('levenshtein')) {
        return $token;
    }
    $lexicon = deenai_keyword_lexicon();
    if (in_array($token, $lexicon, true)) {
        return $token;
    }

    $best = $token;
    $bestDist = PHP_INT_MAX;
    $maxDist = deenai_strlen($token) <= 5 ? 1 : 2;
    foreach ($lexicon as $word) {
        $dist = levenshtein($token, $word);
        if ($dist < $bestDist) {
            $bestDist = $dist;
            $best = $word;
            if ($dist === 0) {
                break;
            }
        }
    }
    if ($bestDist <= $maxDist) {
        return $best;
    }
    return $token;
}

function deenai_strlen(string $value): int {
    if (function_exists('mb_strlen')) {
        return mb_strlen($value, 'UTF-8');
    }
    return strlen($value);
}

function deenai_substr(string $value, int $start, ?int $len = null): string {
    if (function_exists('mb_substr')) {
        return $len === null
            ? mb_substr($value, $start, null, 'UTF-8')
            : mb_substr($value, $start, $len, 'UTF-8');
    }
    return $len === null ? substr($value, $start) : substr($value, $start, $len);
}

function deenai_stripos(string $haystack, string $needle, int $offset = 0): int|false {
    if (function_exists('mb_stripos')) {
        return mb_stripos($haystack, $needle, $offset, 'UTF-8');
    }
    return stripos($haystack, $needle, $offset);
}

function deenai_keywords_from_text(string $value): array {
    $value = deenai_normalize_query_text($value);
    $parts = preg_split('/[^a-z0-9\p{L}]+/u', $value) ?: [];
    $stopWords = [
        'the', 'and', 'for', 'with', 'are', 'you', 'your', 'from', 'that', 'this', 'what',
        'when', 'where', 'which', 'who', 'how', 'can', 'will', 'would', 'could', 'should',
        'about', 'have', 'has', 'had', 'was', 'were', 'into', 'does', 'did', 'not', 'than',
        'then', 'there', 'their', 'them', 'they', 'its', 'our', 'out', 'any', 'all', 'too',
        'ask', 'please', 'question'
    ];
    $stopMap = array_fill_keys($stopWords, true);
    $aliasMap = deenai_keyword_alias_map();
    $tokens = [];
    foreach ($parts as $part) {
        $part = (string)trim((string)$part);
        if ($part === '' || deenai_strlen($part) < 3) {
            continue;
        }
        if (isset($stopMap[$part])) {
            continue;
        }
        $canon = deenai_fuzzy_correct_token($part);
        if (isset($stopMap[$canon])) {
            continue;
        }
        $tokens[] = $canon;
        if (isset($aliasMap[$canon])) {
            foreach ((array)$aliasMap[$canon] as $extra) {
                $extra = deenai_lower((string)$extra);
                if ($extra !== '' && !isset($stopMap[$extra])) {
                    $tokens[] = $extra;
                }
            }
        }
    }
    return array_values(array_unique($tokens, SORT_STRING));
}

function deenai_request_base_path(): string {
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $parts = explode('/', trim($script, '/'));
    if (count($parts) > 0 && strtolower($parts[0]) !== 'api') {
        return '/' . $parts[0];
    }
    return '';
}

function deenai_out_of_scope_message(): string {
    return 'This question is outside the available dataset. Please consult verified scholars.';
}

function deenai_quran_surah_names(): array {
    return [
        1 => ['en' => 'Al-Fatihah', 'ar' => 'الفاتحة'], 2 => ['en' => 'Al-Baqarah', 'ar' => 'البقرة'],
        3 => ['en' => 'Ali Imran', 'ar' => 'آل عمران'], 4 => ['en' => 'An-Nisa', 'ar' => 'النساء'],
        5 => ['en' => 'Al-Ma idah', 'ar' => 'المائدة'], 6 => ['en' => 'Al-Anam', 'ar' => 'الأنعام'],
        7 => ['en' => 'Al-Araf', 'ar' => 'الأعراف'], 8 => ['en' => 'Al-Anfal', 'ar' => 'الأنفال'],
        9 => ['en' => 'At-Tawbah', 'ar' => 'التوبة'], 10 => ['en' => 'Yunus', 'ar' => 'يونس'],
        11 => ['en' => 'Hud', 'ar' => 'هود'], 12 => ['en' => 'Yusuf', 'ar' => 'يوسف'],
        13 => ['en' => 'Ar-Rad', 'ar' => 'الرعد'], 14 => ['en' => 'Ibrahim', 'ar' => 'إبراهيم'],
        15 => ['en' => 'Al-Hijr', 'ar' => 'الحجر'], 16 => ['en' => 'An-Nahl', 'ar' => 'النحل'],
        17 => ['en' => 'Al-Isra', 'ar' => 'الإسراء'], 18 => ['en' => 'Al-Kahf', 'ar' => 'الكهف'],
        19 => ['en' => 'Maryam', 'ar' => 'مريم'], 20 => ['en' => 'Ta-Ha', 'ar' => 'طه'],
        21 => ['en' => 'Al-Anbiya', 'ar' => 'الأنبياء'], 22 => ['en' => 'Al-Hajj', 'ar' => 'الحج'],
        23 => ['en' => 'Al-Muminun', 'ar' => 'المؤمنون'], 24 => ['en' => 'An-Nur', 'ar' => 'النور'],
        25 => ['en' => 'Al-Furqan', 'ar' => 'الفرقان'], 26 => ['en' => 'Ash-Shuara', 'ar' => 'الشعراء'],
        27 => ['en' => 'An-Naml', 'ar' => 'النمل'], 28 => ['en' => 'Al-Qasas', 'ar' => 'القصص'],
        29 => ['en' => 'Al-Ankabut', 'ar' => 'العنكبوت'], 30 => ['en' => 'Ar-Rum', 'ar' => 'الروم'],
        31 => ['en' => 'Luqman', 'ar' => 'لقمان'], 32 => ['en' => 'As-Sajdah', 'ar' => 'السجدة'],
        33 => ['en' => 'Al-Ahzab', 'ar' => 'الأحزاب'], 34 => ['en' => 'Saba', 'ar' => 'سبأ'],
        35 => ['en' => 'Fatir', 'ar' => 'فاطر'], 36 => ['en' => 'Ya-Sin', 'ar' => 'يس'],
        37 => ['en' => 'As-Saffat', 'ar' => 'الصافات'], 38 => ['en' => 'Sad', 'ar' => 'ص'],
        39 => ['en' => 'Az-Zumar', 'ar' => 'الزمر'], 40 => ['en' => 'Ghafir', 'ar' => 'غافر'],
        41 => ['en' => 'Fussilat', 'ar' => 'فصلت'], 42 => ['en' => 'Ash-Shura', 'ar' => 'الشورى'],
        43 => ['en' => 'Az-Zukhruf', 'ar' => 'الزخرف'], 44 => ['en' => 'Ad-Dukhan', 'ar' => 'الدخان'],
        45 => ['en' => 'Al-Jathiyah', 'ar' => 'الجاثية'], 46 => ['en' => 'Al-Ahqaf', 'ar' => 'الأحقاف'],
        47 => ['en' => 'Muhammad', 'ar' => 'محمد'], 48 => ['en' => 'Al-Fath', 'ar' => 'الفتح'],
        49 => ['en' => 'Al-Hujurat', 'ar' => 'الحجرات'], 50 => ['en' => 'Qaf', 'ar' => 'ق'],
        51 => ['en' => 'Adh-Dhariyat', 'ar' => 'الذاريات'], 52 => ['en' => 'At-Tur', 'ar' => 'الطور'],
        53 => ['en' => 'An-Najm', 'ar' => 'النجم'], 54 => ['en' => 'Al-Qamar', 'ar' => 'القمر'],
        55 => ['en' => 'Ar-Rahman', 'ar' => 'الرحمن'], 56 => ['en' => 'Al-Waqiah', 'ar' => 'الواقعة'],
        57 => ['en' => 'Al-Hadid', 'ar' => 'الحديد'], 58 => ['en' => 'Al-Mujadilah', 'ar' => 'المجادلة'],
        59 => ['en' => 'Al-Hashr', 'ar' => 'الحشر'], 60 => ['en' => 'Al-Mumtahanah', 'ar' => 'الممتحنة'],
        61 => ['en' => 'As-Saff', 'ar' => 'الصف'], 62 => ['en' => 'Al-Jumuah', 'ar' => 'الجمعة'],
        63 => ['en' => 'Al-Munafiqun', 'ar' => 'المنافقون'], 64 => ['en' => 'At-Taghabun', 'ar' => 'التغابن'],
        65 => ['en' => 'At-Talaq', 'ar' => 'الطلاق'], 66 => ['en' => 'At-Tahrim', 'ar' => 'التحريم'],
        67 => ['en' => 'Al-Mulk', 'ar' => 'الملك'], 68 => ['en' => 'Al-Qalam', 'ar' => 'القلم'],
        69 => ['en' => 'Al-Haqqah', 'ar' => 'الحاقة'], 70 => ['en' => 'Al-Maarij', 'ar' => 'المعارج'],
        71 => ['en' => 'Nuh', 'ar' => 'نوح'], 72 => ['en' => 'Al-Jinn', 'ar' => 'الجن'],
        73 => ['en' => 'Al-Muzzammil', 'ar' => 'المزمل'], 74 => ['en' => 'Al-Muddaththir', 'ar' => 'المدثر'],
        75 => ['en' => 'Al-Qiyamah', 'ar' => 'القيامة'], 76 => ['en' => 'Al-Insan', 'ar' => 'الإنسان'],
        77 => ['en' => 'Al-Mursalat', 'ar' => 'المرسلات'], 78 => ['en' => 'An-Naba', 'ar' => 'النبأ'],
        79 => ['en' => 'An-Naziat', 'ar' => 'النازعات'], 80 => ['en' => 'Abasa', 'ar' => 'عبس'],
        81 => ['en' => 'At-Takwir', 'ar' => 'التكوير'], 82 => ['en' => 'Al-Infitar', 'ar' => 'الإنفطار'],
        83 => ['en' => 'Al-Mutaffifin', 'ar' => 'المطففين'], 84 => ['en' => 'Al-Inshiqaq', 'ar' => 'الانشقاق'],
        85 => ['en' => 'Al-Buruj', 'ar' => 'البروج'], 86 => ['en' => 'At-Tariq', 'ar' => 'الطارق'],
        87 => ['en' => 'Al-Ala', 'ar' => 'الأعلى'], 88 => ['en' => 'Al-Ghashiyah', 'ar' => 'الغاشية'],
        89 => ['en' => 'Al-Fajr', 'ar' => 'الفجر'], 90 => ['en' => 'Al-Balad', 'ar' => 'البلد'],
        91 => ['en' => 'Ash-Shams', 'ar' => 'الشمس'], 92 => ['en' => 'Al-Layl', 'ar' => 'الليل'],
        93 => ['en' => 'Ad-Duha', 'ar' => 'الضحى'], 94 => ['en' => 'Ash-Sharh', 'ar' => 'الشرح'],
        95 => ['en' => 'At-Tin', 'ar' => 'التين'], 96 => ['en' => 'Al-Alaq', 'ar' => 'العلق'],
        97 => ['en' => 'Al-Qadr', 'ar' => 'القدر'], 98 => ['en' => 'Al-Bayyinah', 'ar' => 'البينة'],
        99 => ['en' => 'Az-Zalzalah', 'ar' => 'الزلزلة'], 100 => ['en' => 'Al-Adiyat', 'ar' => 'العاديات'],
        101 => ['en' => 'Al-Qariah', 'ar' => 'القارعة'], 102 => ['en' => 'At-Takathur', 'ar' => 'التكاثر'],
        103 => ['en' => 'Al-Asr', 'ar' => 'العصر'], 104 => ['en' => 'Al-Humazah', 'ar' => 'الهمزة'],
        105 => ['en' => 'Al-Fil', 'ar' => 'الفيل'], 106 => ['en' => 'Quraysh', 'ar' => 'قريش'],
        107 => ['en' => 'Al-Maun', 'ar' => 'الماعون'], 108 => ['en' => 'Al-Kawthar', 'ar' => 'الكوثر'],
        109 => ['en' => 'Al-Kafirun', 'ar' => 'الكافرون'], 110 => ['en' => 'An-Nasr', 'ar' => 'النصر'],
        111 => ['en' => 'Al-Masad', 'ar' => 'المسد'], 112 => ['en' => 'Al-Ikhlas', 'ar' => 'الإخلاص'],
        113 => ['en' => 'Al-Falaq', 'ar' => 'الفلق'], 114 => ['en' => 'An-Nas', 'ar' => 'الناس']
    ];
}

function deenai_quran_surah_aliases(): array {
    $names = deenai_quran_surah_names();
    $aliases = [];
    foreach ($names as $num => $meta) {
        $en = deenai_lower((string)($meta['en'] ?? ''));
        $norm = preg_replace('/[^a-z0-9]+/u', ' ', $en) ?? $en;
        $norm = deenai_clean_text(str_replace('al ', '', $norm));
        if ($norm !== '') {
            $aliases[$norm] = $num;
        }
        $aliases[deenai_clean_text($en)] = $num;
    }
    $manual = [
        'fatiha' => 1, 'fatihah' => 1, 'baqarah' => 2, 'imran' => 3, 'nisa' => 4,
        'maida' => 5, 'anam' => 6, 'araf' => 7, 'tawbah' => 9, 'yunus' => 10, 'hud' => 11,
        'yusuf' => 12, 'kahf' => 18, 'maryam' => 19, 'ta ha' => 20, 'yasin' => 36,
        'rahman' => 55, 'mulk' => 67, 'ikhlas' => 112, 'falaq' => 113, 'nas' => 114
    ];
    foreach ($manual as $alias => $num) {
        $aliases[$alias] = $num;
    }
    return $aliases;
}

function deenai_quran_surah_meta(int $surah): array {
    $all = deenai_quran_surah_names();
    return $all[$surah] ?? ['en' => 'Unknown Surah', 'ar' => ''];
}

function deenai_quran_reference(int $surah, int $ayah = 0): string {
    $meta = deenai_quran_surah_meta($surah);
    $en = (string)($meta['en'] ?? 'Unknown Surah');
    if ($ayah > 0) {
        return "Surah {$en} ({$surah}):{$ayah}";
    }
    return "Surah {$en} ({$surah})";
}

function deenai_normalize_bool(mixed $value, bool $default = false): bool {
    if ($value === null) {
        return $default;
    }
    if (is_bool($value)) {
        return $value;
    }
    $v = strtolower(trim((string)$value));
    if (in_array($v, ['1', 'true', 'yes', 'on'], true)) {
        return true;
    }
    if (in_array($v, ['0', 'false', 'no', 'off'], true)) {
        return false;
    }
    return $default;
}
