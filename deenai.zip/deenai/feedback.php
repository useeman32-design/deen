<?php
declare(strict_types=1);

require_once __DIR__ . '/common.php';
require_once __DIR__ . '/schema.php';

try {
    $input = deenai_require_post_json_with_csrf();
    $queryLogId = (int)($input['query_log_id'] ?? 0);
    $helpfulRaw = $input['helpful'] ?? null;
    $helpful = deenai_normalize_bool($helpfulRaw, true);
    $correction = isset($input['correction']) ? (string)$input['correction'] : null;

    if ($queryLogId <= 0) {
        deenai_json(400, ['status' => 'error', 'message' => 'query_log_id is required']);
    }

    $pdo = deenai_db();
    deenai_ensure_schema($pdo);
    $userId = deenai_current_user_id();
    deenai_save_feedback($pdo, $userId, $queryLogId, $helpful, $correction);

    deenai_json(200, [
        'status' => 'success',
        'message' => 'Feedback saved'
    ]);
} catch (Throwable $e) {
    error_log('deenai feedback error: ' . $e->getMessage());
    deenai_json(500, ['status' => 'error', 'message' => 'Server error']);
}

