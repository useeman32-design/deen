<?php
declare(strict_types=1);

require_once __DIR__ . '/common.php';

function deenai_pick_chat_variant(array $replies, string $seed = ''): string {
    if (empty($replies)) {
        return '';
    }
    $count = count($replies);
    if ($count === 1) {
        return (string)$replies[0];
    }
    try {
        $idx = random_int(0, $count - 1);
    } catch (Throwable) {
        $idx = (int)(crc32((string)microtime(true) . '|' . $seed) % $count);
        if ($idx < 0) {
            $idx = 0;
        }
    }
    return (string)$replies[$idx];
}

function deenai_is_salam_text(string $lower): bool {
    return preg_match('/\b(assalamu?\s*alaikum|assalamu?\s*alaykum|as-?salam(u)?|assalam|salaam|salam)\b/u', $lower) === 1
        || preg_match('/\b(wa\s*alaikum\s*assalam|wa\s*alaykum\s*assalam)\b/u', $lower) === 1;
}

/**
 * Conversation gate:
 * Handles greetings/thanks/help before retrieval and before LLM.
 */
function deenai_conversation_gate_response(string $question): ?array {
    $q = deenai_normalize_query_text($question);
    if ($q === '') {
        return null;
    }
    $lower = deenai_lower($q);

    if (deenai_is_salam_text($lower)) {
        $reply = deenai_pick_chat_variant([
            'Wa alaikum assalam wa rahmatullah. Ask your question any time.',
            'Wa alaikum assalam. I am here and ready to help from your DeenLink datasets.',
            'Assalamu alaikum wa rahmatullah. You can chat with me or ask your Islamic question.'
        ], $question);
        return [
            'label' => 'greeting',
            'reply' => $reply
        ];
    }

    $greetings = ['hello', 'hi', 'hey', 'good morning', 'good evening', 'good afternoon'];
    foreach ($greetings as $g) {
        if ($lower === $g || str_starts_with($lower, $g . ' ') || str_contains($lower, ' ' . $g . ' ')) {
            $reply = deenai_pick_chat_variant([
                'Wa alaikum assalam. I am DeenLink AI. Ask your Islamic question and I will answer from available local datasets.',
                'Assalamu alaikum wa rahmatullah. I am ready. Ask any Islamic question from your DeenLink datasets.',
                'Wa alaikum assalam. Welcome back. You can ask about Quran, Hadith, dua, names of Allah, and more from your local data.'
            ], $question);
            return [
                'label' => 'greeting',
                'reply' => $reply
            ];
        }
    }

    $thanks = ['thank you', 'thanks', 'jazakallah', 'jazakallahu khayran', 'barakallahu feek'];
    foreach ($thanks as $t) {
        if ($lower === $t || str_starts_with($lower, $t . ' ') || str_contains($lower, ' ' . $t)) {
            $reply = deenai_pick_chat_variant([
                'You are welcome. May Allah reward you. Ask another question anytime.',
                'Wa iyyakum. May Allah increase you in beneficial knowledge.',
                'You are welcome. I am here whenever you want to continue.'
            ], $question);
            return [
                'label' => 'thanks',
                'reply' => $reply
            ];
        }
    }

    $help = ['help', 'what can you do', 'how do i use', 'how to use', 'who are you'];
    foreach ($help as $h) {
        if ($lower === $h || str_contains($lower, $h)) {
            $reply = deenai_pick_chat_variant([
                'I can answer from your local Quran, Hadith, Dua/Adhkar, 99 Names, fiqh and fatwa datasets. Ask in natural language, for example: "Will this break my fast?" or "Give me a dua for anxiety."',
                'I answer only from your local Islamic datasets. You can ask for ayahs, hadith, duas, names of Allah, and practical guidance from available sources.',
                'Ask naturally. I will route your question to the right local dataset and return source-based answers only.'
            ], $question);
            return [
                'label' => 'help',
                'reply' => $reply
            ];
        }
    }

    $casual = [
        'how are you',
        'can we chat',
        'let us chat',
        'lets chat',
        'talk to me',
        'just want to chat',
        'i am bored',
        'what are you doing',
        'how is your day'
    ];
    foreach ($casual as $c) {
        if ($lower === $c || str_contains($lower, $c)) {
            $reply = deenai_pick_chat_variant([
                'We can chat. I also answer Islamic questions from your local datasets whenever you are ready.',
                'Yes, we can chat. If you want, ask me anything about Quran, Hadith, dua, or Islamic history from your data.',
                'Sure, we can talk. You can also switch to an Islamic question any time.'
            ], $question);
            return [
                'label' => 'casual_chat',
                'reply' => $reply
            ];
        }
    }

    return null;
}

/**
 * Rule-based lightweight classification layer.
 * This is additive and does not replace deterministic intent detection.
 */
function deenai_classify_question(string $question): array {
    $q = deenai_normalize_query_text($question);
    $lower = deenai_lower($q);

    $guidanceSignals = [
        'fear', 'afraid', 'scared', 'anxiety', 'anxious', 'worry', 'worried', 'stress',
        'depression', 'depressed', 'panic', 'evil eye', 'hasad', 'envy', 'sihr',
        'protection', 'protect me', 'forgive me', 'forgiveness', 'repent', 'tawbah',
        'patience', 'sabr', 'dua', 'duaa', 'adhkar', 'azkar', 'zikr', 'dhikr',
        'before sleep', 'going to bed', 'morning adhkar', 'evening adhkar',
        'remembrance', 'supplication'
    ];

    $personalSignals = [
        'is my fast broken', 'is my fasting broken', 'is my prayer valid', 'is this a sin',
        'am i going to hell', 'will i go to hell', 'will allah forgive me',
        'is this haram', 'is this halal', 'can i marry', 'is my marriage valid',
        'did i commit shirk', 'did i commit kufr'
    ];

    $isGuidance = false;
    foreach ($guidanceSignals as $signal) {
        if (str_contains($lower, $signal)) {
            $isGuidance = true;
            break;
        }
    }

    $isPersonal = false;
    foreach ($personalSignals as $signal) {
        if (str_contains($lower, $signal)) {
            $isPersonal = true;
            break;
        }
    }
    if (!$isPersonal && preg_match('/\b(is|am|does|did|can)\b.+\b(haram|halal|sin|valid|broken|accepted)\b/i', $q)) {
        $isPersonal = true;
    }

    if ($isPersonal) {
        return [
            'label' => 'personal_verdict',
            'preferred_types' => ['fiqh', 'fatwa', 'quran', 'hadith', 'dua', 'adhkar'],
            'safety_modifier' => true
        ];
    }

    if ($isGuidance) {
        return [
            'label' => 'guidance',
            'preferred_types' => ['dua', 'adhkar', 'asmaulhusna', 'quran', 'hadith'],
            'safety_modifier' => false
        ];
    }

    return [
        'label' => 'informational',
        'preferred_types' => ['quran', 'hadith', 'faq', 'fiqh', 'fatwa'],
        'safety_modifier' => false
    ];
}

function deenai_detect_intent(string $question): ?array {
    $q = deenai_normalize_query_text($question);
    if ($q === '') {
        return null;
    }

    $lower = deenai_lower($q);
    $tokens = deenai_keywords_from_text($q);

    $intentRules = [
        'quran_ayah_count' => [
            'types' => ['quran'],
            'must' => ['ayah count', 'verse count', 'how many ayah', 'how many verses', 'number of verses']
        ],
        'quran_ayah_lookup' => [
            'types' => ['quran'],
            'must' => ['surah', 'quran', 'ayah', 'verse', ':']
        ],
        'hadith_lookup' => [
            'types' => ['hadith'],
            'must' => ['hadith', 'bukhari', 'muslim', 'tirmidhi', 'abu dawud', 'ibn majah', 'nawawi', 'sunnah']
        ],
        'dua_adhkar_lookup' => [
            'types' => ['dua', 'adhkar'],
            'must' => ['dua', 'duaa', 'adhkar', 'azkar', 'dhikr', 'zikr', 'supplication']
        ],
        'asmaulhusna_lookup' => [
            'types' => ['asmaulhusna'],
            'must' => ['99 names', 'names of allah', 'asmaul husna', 'asma ul husna']
        ],
        'fiqh_explanation' => [
            'types' => ['fiqh'],
            'must' => ['fiqh', 'ruling', 'halal', 'haram', 'wudu', 'salah', 'zakat', 'fasting', 'hajj']
        ],
        'aqeedah_explanation' => [
            'types' => ['aqeedah'],
            'must' => ['aqeedah', 'creed', 'tawhid', 'iman', 'belief']
        ],
        'fatwa_lookup' => [
            'types' => ['fatwa'],
            'must' => ['fatwa', 'verdict', 'mufti']
        ],
        'book_story_lookup' => [
            'types' => ['book', 'story'],
            'must' => ['story', 'book', 'seerah', 'history']
        ],
        'faq_lookup' => [
            'types' => ['faq'],
            'must' => ['faq', 'frequently asked', 'question answer']
        ]
    ];

    $surahAyah = deenai_parse_surah_ayah($q);
    $scores = [];
    foreach ($intentRules as $intent => $rule) {
        $score = 0;
        foreach ($rule['must'] as $needle) {
            if (str_contains($lower, $needle)) {
                $score += 2;
            }
        }
        if ($intent === 'quran_ayah_lookup' && ($surahAyah['surah'] ?? 0) > 0) {
            $score += 4;
        }
        if ($intent === 'quran_ayah_count' && ($surahAyah['surah'] ?? 0) > 0) {
            $score += 5;
        }
        if ($intent === 'hadith_lookup' && preg_match('/\bhadith\b\s*#?\s*\d+/i', $q)) {
            $score += 2;
        }
        $scores[$intent] = $score;
    }

    arsort($scores);
    $topIntent = (string)key($scores);
    $topScore = (int)current($scores);
    if ($topScore <= 0) {
        return null;
    }

    return [
        'intent' => $topIntent,
        'types' => $intentRules[$topIntent]['types'],
        'tokens' => $tokens,
        'query' => $q,
        'surah' => (int)($surahAyah['surah'] ?? 0),
        'ayah' => (int)($surahAyah['ayah'] ?? 0),
        'score' => $topScore
    ];
}

function deenai_apply_classification_to_intent(?array $intentCtx, array $classification, string $question): array {
    $tokens = deenai_keywords_from_text($question);
    $parsed = deenai_parse_surah_ayah($question);

    if (!is_array($intentCtx)) {
        $intentCtx = [
            'intent' => $classification['label'] . '_lookup',
            'types' => [],
            'tokens' => $tokens,
            'query' => deenai_normalize_query_text($question),
            'surah' => (int)($parsed['surah'] ?? 0),
            'ayah' => (int)($parsed['ayah'] ?? 0),
            'score' => 0
        ];
    }

    $intentCtx['tokens'] = is_array($intentCtx['tokens'] ?? null) ? $intentCtx['tokens'] : $tokens;
    $currentTypes = is_array($intentCtx['types'] ?? null) ? $intentCtx['types'] : [];
    $preferred = is_array($classification['preferred_types'] ?? null) ? $classification['preferred_types'] : [];
    $intentCtx['types'] = array_values(array_unique(array_merge($preferred, $currentTypes), SORT_STRING));
    if (empty($intentCtx['types'])) {
        $intentCtx['types'] = ['quran', 'hadith', 'faq'];
    }
    $intentCtx['classification'] = (string)($classification['label'] ?? 'informational');
    return $intentCtx;
}

/**
 * Hard lock for explicit user asks.
 * Prevents cross-category retrieval (e.g., hadith question returning dua dataset).
 */
function deenai_detect_explicit_type_lock(string $question): ?array {
    $q = deenai_normalize_query_text($question);
    if ($q === '') {
        return null;
    }
    $lower = deenai_lower($q);
    $tokens = deenai_keywords_from_text($q);
    $tokenMap = array_fill_keys($tokens, true);
    $types = [];

    $hasToken = static function (string $token) use ($tokenMap): bool {
        return isset($tokenMap[$token]);
    };

    $hasQuran = str_contains($lower, 'quran')
        || str_contains($lower, 'surah')
        || str_contains($lower, 'ayah')
        || str_contains($lower, 'verse')
        || $hasToken('quran') || $hasToken('ayah') || $hasToken('verse')
        || preg_match('/\b\d{1,3}\s*[:\-]\s*\d{1,3}\b/u', $lower) === 1;
    if ($hasQuran) {
        $types[] = 'quran';
    }

    $hasHadith = str_contains($lower, 'hadith')
        || str_contains($lower, 'bukhari')
        || str_contains($lower, 'buhari')
        || str_contains($lower, 'muslim')
        || str_contains($lower, 'tirmidhi')
        || str_contains($lower, 'nawawi')
        || str_contains($lower, 'abu dawud')
        || str_contains($lower, 'ibn majah')
        || str_contains($lower, 'sunnah')
        || $hasToken('hadith') || $hasToken('sunnah');
    if ($hasHadith) {
        $types[] = 'hadith';
    }

    $hasDua = str_contains($lower, 'dua')
        || str_contains($lower, 'duaa')
        || str_contains($lower, 'adhkar')
        || str_contains($lower, 'azkar')
        || str_contains($lower, 'dhikr')
        || str_contains($lower, 'zikr')
        || str_contains($lower, 'supplication')
        || str_contains($lower, 'invocation')
        || str_contains($lower, 'before sleep')
        || str_contains($lower, 'going to bed')
        || str_contains($lower, 'before bed')
        || str_contains($lower, 'morning adhkar')
        || str_contains($lower, 'evening adhkar')
        || str_contains($lower, 'remembrance')
        || $hasToken('dua') || $hasToken('adhkar') || $hasToken('supplication');
    if ($hasDua) {
        $types[] = 'dua';
        $types[] = 'adhkar';
    }

    $hasNames = str_contains($lower, '99 names')
        || str_contains($lower, 'names of allah')
        || str_contains($lower, 'asmaul husna')
        || str_contains($lower, 'asma ul husna')
        || str_contains($lower, 'asmaulhusna')
        || $hasToken('asmaulhusna');
    if ($hasNames) {
        $types[] = 'asmaulhusna';
    }

    $hasCoreSourceLock = $hasQuran || $hasHadith || $hasDua || $hasNames;

    $hasStory = str_contains($lower, 'seerah')
        || str_contains($lower, 'sirah')
        || str_contains($lower, 'history')
        || str_contains($lower, 'event')
        || str_contains($lower, 'battle of')
        || str_contains($lower, 'badr')
        || str_contains($lower, 'uhud')
        || str_contains($lower, 'hijrah')
        || str_contains($lower, 'makkah')
        || str_contains($lower, 'madinah')
        || $hasToken('seerah') || $hasToken('history') || $hasToken('event');
    if ($hasStory && !$hasCoreSourceLock) {
        $types[] = 'story';
        $types[] = 'book';
    }

    $hasFatwa = str_contains($lower, 'fatwa')
        || str_contains($lower, 'ruling')
        || str_contains($lower, 'mufti');
    if ($hasFatwa && !$hasCoreSourceLock) {
        $types[] = 'fatwa';
        $types[] = 'fiqh';
    }

    $types = array_values(array_unique($types, SORT_STRING));
    if (empty($types)) {
        return null;
    }
    return [
        'types' => $types,
        'reason' => 'explicit_type_request'
    ];
}

function deenai_apply_explicit_type_lock(array $intentCtx, string $question): array {
    $lock = deenai_detect_explicit_type_lock($question);
    if (!is_array($lock) || empty($lock['types'])) {
        $intentCtx['explicit_type_lock'] = false;
        return $intentCtx;
    }

    $types = array_values(array_unique((array)$lock['types'], SORT_STRING));
    if (empty($types)) {
        $intentCtx['explicit_type_lock'] = false;
        return $intentCtx;
    }

    $intentCtx['types'] = $types;
    $intentCtx['explicit_type_lock'] = true;
    $intentCtx['explicit_lock_reason'] = (string)($lock['reason'] ?? 'explicit_type_request');

    if (count($types) === 1) {
        $intentCtx['intent'] = match ($types[0]) {
            'quran' => 'quran_ayah_lookup',
            'hadith' => 'hadith_lookup',
            'dua', 'adhkar' => 'dua_adhkar_lookup',
            'asmaulhusna' => 'asmaulhusna_lookup',
            'fatwa' => 'fatwa_lookup',
            'fiqh' => 'fiqh_explanation',
            'story', 'book' => 'book_story_lookup',
            default => (string)($intentCtx['intent'] ?? 'dataset_lookup')
        };
    }

    return $intentCtx;
}

function deenai_requested_result_count(string $question, array $classification): int {
    $lower = deenai_normalize_query_text($question);

    // Keep precise Quran verse lookup to single result.
    if (preg_match('/\b\d{1,3}\s*[:\-]\s*\d{1,3}\b/u', $lower) === 1
        || preg_match('/\bsurah\s+\d{1,3}\b.*\bayah\s+\d{1,3}\b/u', $lower) === 1) {
        return 1;
    }

    if (preg_match('/\b([1-9]|10)\b/u', $lower, $m) === 1) {
        $n = (int)$m[1];
        if ($n >= 1 && $n <= 10) {
            return $n;
        }
    }

    $wantsList = preg_match('/\b(list|many|more|several|all|multiple)\b/i', $lower) === 1;
    if ($wantsList || preg_match('/\b(3|4|5|6|7|8|9|10)\b/', $lower)) {
        return 5;
    }
    if (($classification['label'] ?? '') === 'guidance') {
        return 3;
    }
    return 1;
}

function deenai_parse_surah_ayah(string $question): array {
    $q = deenai_normalize_query_text($question);
    $surah = 0;
    $ayah = 0;

    if (preg_match('/\b(\d{1,3})\s*[:\-]\s*(\d{1,3})\b/u', $q, $m)) {
        return ['surah' => (int)$m[1], 'ayah' => (int)$m[2]];
    }
    if (preg_match('/\bsurah\s+(\d{1,3})(?:\D+ayah\s+(\d{1,3}))?/iu', $q, $m)) {
        $surah = (int)$m[1];
        $ayah = isset($m[2]) ? (int)$m[2] : 0;
        return ['surah' => $surah, 'ayah' => $ayah];
    }

    $lower = deenai_lower($q);
    $surahMap = deenai_quran_surah_aliases();
    foreach ($surahMap as $name => $num) {
        if ($name !== '' && str_contains($lower, $name)) {
            $surah = (int)$num;
            break;
        }
    }
    if ($surah <= 0 && function_exists('levenshtein')) {
        $tokens = deenai_keywords_from_text($q);
        $best = 0;
        $bestDist = 99;
        foreach ($tokens as $tok) {
            foreach ($surahMap as $name => $num) {
                if (str_contains($name, ' ') || deenai_strlen($name) < 4) {
                    continue;
                }
                $dist = levenshtein($tok, $name);
                if ($dist < $bestDist) {
                    $bestDist = $dist;
                    $best = (int)$num;
                }
            }
        }
        if ($best > 0 && $bestDist <= 1) {
            $surah = $best;
        }
    }
    if ($surah > 0 && preg_match('/\bayah\s+(\d{1,3})\b/iu', $q, $m)) {
        $ayah = (int)$m[1];
    }
    return ['surah' => $surah, 'ayah' => $ayah];
}
