<?php
declare(strict_types=1);

require_once __DIR__ . '/common.php';

function deenai_extract_first_json_object(string $raw): ?array {
    $text = trim($raw);
    if ($text === '') {
        return null;
    }
    $decoded = json_decode($text, true);
    if (is_array($decoded)) {
        return $decoded;
    }

    $start = strpos($text, '{');
    $end = strrpos($text, '}');
    if ($start === false || $end === false || $end <= $start) {
        return null;
    }
    $slice = substr($text, $start, ($end - $start + 1));
    if (!is_string($slice) || $slice === '') {
        return null;
    }
    $decoded = json_decode($slice, true);
    return is_array($decoded) ? $decoded : null;
}

function deenai_normalize_router_category(string $rawCategory, array $allowedCategories): string {
    $raw = deenai_lower(deenai_clean_text($rawCategory));
    if ($raw === '') {
        return 'out_of_scope';
    }

    $mapped = match ($raw) {
        '99names', '99_names', 'names_of_allah', 'asmaul_husna', 'asma ul husna' => 'asmaulhusna',
        'chat', 'smalltalk', 'small_talk' => 'casual_chat',
        'guidance', 'general_guidance', 'general' => 'general_islamic_guidance',
        'combined', 'combination', 'combined_response' => 'combinational_response',
        default => $raw
    };

    $allowed = array_fill_keys(array_map(static fn($x) => deenai_lower((string)$x), $allowedCategories), true);
    if (isset($allowed[$mapped])) {
        return $mapped;
    }
    if ($mapped === 'asmaulhusna' && isset($allowed['99names'])) {
        return '99names';
    }
    if ($mapped === '99names' && isset($allowed['asmaulhusna'])) {
        return 'asmaulhusna';
    }
    return 'out_of_scope';
}

/**
 * Lightweight LLM router:
 * question -> {category, confidence}. No dataset context is sent.
 */
function deenai_route_question_with_fallback(
    array $providerConfig,
    string $question,
    array $allowedCategories
): array {
    $allowedCategories = array_values(array_unique(array_filter(array_map('strval', $allowedCategories), static fn(string $v): bool => trim($v) !== '')));
    if (empty($allowedCategories)) {
        $allowedCategories = ['general_islamic_guidance', 'casual_chat', 'out_of_scope'];
    }

    $systemPrompt = "You are an Islamic AI routing assistant. "
        . "Classify the user message into exactly one allowed category. "
        . "Return only strict JSON with keys category and confidence. "
        . "Do not provide explanations.";
    $userPrompt = "Allowed categories:\n- " . implode("\n- ", $allowedCategories)
        . "\n\nUser question:\n" . $question
        . "\n\nReturn JSON only like {\"category\":\"...\",\"confidence\":0}.";

    $order = ['groq', 'gemini', 'openrouter', 'huggingface'];
    $attempts = [];
    foreach ($order as $provider) {
        $cfg = $providerConfig[$provider] ?? null;
        if (!is_array($cfg) || empty($cfg['active']) || trim((string)($cfg['api_key'] ?? '')) === '') {
            $attempts[] = [
                'provider' => $provider,
                'status' => 'failed',
                'model' => null,
                'latency_ms' => 0,
                'error' => 'Provider key missing or inactive'
            ];
            continue;
        }

        $model = trim((string)($cfg['model_name'] ?? ''));
        if ($model === '') {
            $model = deenai_default_model_for_provider($provider);
        }

        $start = microtime(true);
        try {
            $text = deenai_call_provider($provider, (string)$cfg['api_key'], $model, $systemPrompt, $userPrompt, 140);
            $latency = (int)round((microtime(true) - $start) * 1000);
            $parsed = deenai_extract_first_json_object($text);
            if (!is_array($parsed)) {
                throw new RuntimeException('Router JSON parse failed');
            }

            $category = deenai_normalize_router_category((string)($parsed['category'] ?? ''), $allowedCategories);
            $confidence = (int)($parsed['confidence'] ?? 0);
            $confidence = max(0, min(100, $confidence));
            if ($category === 'out_of_scope' && !in_array('out_of_scope', $allowedCategories, true)) {
                $category = 'general_islamic_guidance';
            }

            $attempts[] = [
                'provider' => $provider,
                'status' => 'success',
                'model' => $model,
                'latency_ms' => $latency,
                'error' => null
            ];
            return [
                'ok' => true,
                'category' => $category,
                'confidence' => $confidence,
                'provider' => $provider,
                'model' => $model,
                'attempts' => $attempts
            ];
        } catch (Throwable $e) {
            $attempts[] = [
                'provider' => $provider,
                'status' => 'failed',
                'model' => $model,
                'latency_ms' => (int)round((microtime(true) - $start) * 1000),
                'error' => $e->getMessage()
            ];
        }
    }

    return [
        'ok' => false,
        'category' => 'out_of_scope',
        'confidence' => 0,
        'provider' => null,
        'model' => null,
        'attempts' => $attempts
    ];
}

/**
 * Combined selector:
 * confirms category and returns best candidate IDs in one small call.
 */
function deenai_route_and_select_with_fallback(
    array $providerConfig,
    string $question,
    array $candidates,
    array $allowedCategories,
    string $hintCategory,
    int $topN = 2
): array {
    $topN = max(1, min(3, $topN));
    if (empty($candidates)) {
        return [
            'ok' => false,
            'category' => $hintCategory !== '' ? $hintCategory : 'out_of_scope',
            'ids' => [],
            'provider' => null,
            'model' => null,
            'attempts' => []
        ];
    }

    $allowedCategories = array_values(array_unique(array_filter(array_map('strval', $allowedCategories), static fn(string $v): bool => trim($v) !== '')));
    if (empty($allowedCategories)) {
        $allowedCategories = ['general_islamic_guidance', 'out_of_scope'];
    }

    $candidateIds = [];
    $lines = [];
    $trimmedCandidates = array_slice($candidates, 0, 15);
    foreach ($trimmedCandidates as $candidate) {
        $cid = (int)($candidate['_cid'] ?? 0);
        if ($cid <= 0) {
            continue;
        }
        $candidateIds[$cid] = true;
        $reference = deenai_clean_text((string)($candidate['reference'] ?? ''));
        $snippet = trim((string)($candidate['english'] ?? $candidate['text'] ?? $candidate['arabic'] ?? ''));
        $snippet = deenai_clean_text($snippet);
        if ($snippet === '') {
            continue;
        }
        if (deenai_strlen($snippet) > 300) {
            $snippet = deenai_substr($snippet, 0, 300);
        }
        $lines[] = 'ID ' . $cid . ': ' . ($reference !== '' ? ($reference . ' | ') : '') . $snippet;
    }

    if (empty($lines)) {
        return [
            'ok' => false,
            'category' => $hintCategory !== '' ? $hintCategory : 'out_of_scope',
            'ids' => [],
            'provider' => null,
            'model' => null,
            'attempts' => []
        ];
    }

    $systemPrompt = "You are an Islamic relevance selector. "
        . "Confirm the best category and choose up to {$topN} best IDs. "
        . "Do not generate explanations and do not invent content. "
        . "Return strict JSON only: {\"category\":\"...\",\"best_ids\":[1,2]}.";
    $userPrompt = "Allowed categories:\n- " . implode("\n- ", $allowedCategories)
        . "\nHint category: " . $hintCategory
        . "\n\nQuestion:\n" . $question
        . "\n\nCandidates:\n" . implode("\n", $lines)
        . "\n\nReturn JSON only.";

    $order = ['groq', 'gemini', 'openrouter', 'huggingface'];
    $attempts = [];
    foreach ($order as $provider) {
        $cfg = $providerConfig[$provider] ?? null;
        if (!is_array($cfg) || empty($cfg['active']) || trim((string)($cfg['api_key'] ?? '')) === '') {
            $attempts[] = [
                'provider' => $provider,
                'status' => 'failed',
                'model' => null,
                'latency_ms' => 0,
                'error' => 'Provider key missing or inactive'
            ];
            continue;
        }

        $model = trim((string)($cfg['model_name'] ?? ''));
        if ($model === '') {
            $model = deenai_default_model_for_provider($provider);
        }

        $start = microtime(true);
        try {
            $text = deenai_call_provider($provider, (string)$cfg['api_key'], $model, $systemPrompt, $userPrompt, 200);
            $latency = (int)round((microtime(true) - $start) * 1000);
            $parsed = deenai_extract_first_json_object($text);
            if (!is_array($parsed)) {
                throw new RuntimeException('Selector JSON parse failed');
            }

            $category = deenai_normalize_router_category((string)($parsed['category'] ?? $hintCategory), $allowedCategories);
            if ($category === 'out_of_scope' && $hintCategory !== '') {
                $category = deenai_normalize_router_category($hintCategory, $allowedCategories);
            }

            $ids = deenai_extract_ranked_ids(
                json_encode($parsed['best_ids'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '',
                array_keys($candidateIds),
                $topN
            );
            if (empty($ids) && isset($parsed['best_ids']) && is_array($parsed['best_ids'])) {
                foreach ($parsed['best_ids'] as $v) {
                    $id = (int)$v;
                    if ($id > 0 && isset($candidateIds[$id])) {
                        $ids[] = $id;
                    }
                }
                $ids = array_values(array_unique($ids));
                if (count($ids) > $topN) {
                    $ids = array_slice($ids, 0, $topN);
                }
            }
            if (empty($ids)) {
                throw new RuntimeException('Selector returned no valid IDs');
            }

            $attempts[] = [
                'provider' => $provider,
                'status' => 'success',
                'model' => $model,
                'latency_ms' => $latency,
                'error' => null
            ];
            return [
                'ok' => true,
                'category' => $category,
                'ids' => $ids,
                'provider' => $provider,
                'model' => $model,
                'attempts' => $attempts
            ];
        } catch (Throwable $e) {
            $attempts[] = [
                'provider' => $provider,
                'status' => 'failed',
                'model' => $model,
                'latency_ms' => (int)round((microtime(true) - $start) * 1000),
                'error' => $e->getMessage()
            ];
        }
    }

    return [
        'ok' => false,
        'category' => $hintCategory !== '' ? $hintCategory : 'out_of_scope',
        'ids' => [],
        'provider' => null,
        'model' => null,
        'attempts' => $attempts
    ];
}

/**
 * LLM wrapper with strict fallback order:
 * Groq -> Gemini -> OpenRouter -> Hugging Face.
 *
 * Anti-hallucination: prompt instructs model to use only supplied context.
 */
function deenai_generate_explanation_with_fallback(
    array $providerConfig,
    string $question,
    array $extractedItems,
    int $maxChars = 1800,
    array $options = []
): array {
    if (empty($extractedItems)) {
        return [
            'ok' => false,
            'explanation' => '',
            'provider' => null,
            'model' => null,
            'attempts' => []
        ];
    }

    $contextLines = [];
    foreach ($extractedItems as $idx => $item) {
        $num = $idx + 1;
        $reference = trim((string)($item['reference'] ?? ''));
        $arabic = trim((string)($item['arabic'] ?? ''));
        $english = trim((string)($item['english'] ?? ''));
        $text = trim((string)($item['text'] ?? ''));
        $parts = [];
        if ($reference !== '') {
            $parts[] = "Reference: {$reference}";
        }
        if ($arabic !== '') {
            $parts[] = "Arabic: {$arabic}";
        }
        if ($english !== '') {
            $parts[] = "English: {$english}";
        }
        if ($text !== '') {
            $parts[] = "Text: {$text}";
        }
        if (!$parts) {
            continue;
        }
        $contextLines[] = '[' . $num . '] ' . implode("\n", $parts);
    }

    $contextBlock = implode("\n\n", $contextLines);
    if (trim($contextBlock) === '') {
        return [
            'ok' => false,
            'explanation' => '',
            'provider' => null,
            'model' => null,
            'attempts' => []
        ];
    }

    $systemPrompt = "You are DeenLink AI explanation assistant. "
        . "You MUST only explain content from supplied dataset excerpts. "
        . "Do NOT create new Islamic rulings, beliefs, fatwas, or interpretations. "
        . "For Quran excerpts, begin naturally with 'Allah says'. "
        . "For Hadith excerpts, begin naturally with 'Prophet Muhammad (peace be upon him) said'. "
        . "If context does not answer the question, reply exactly: "
        . "\"" . deenai_out_of_scope_message() . "\"";
    if (!empty($options['personal_verdict'])) {
        $systemPrompt .= " For personal verdict questions, do not issue a definitive ruling. "
            . "Only state general principles from the provided excerpts and advise consulting verified scholars.";
    }
    if (!empty($options['guidance_mode'])) {
        $systemPrompt .= " For guidance questions, keep the response warm and practical, and mention when the supplication is commonly recited.";
    }

    $userPrompt = "Question:\n{$question}\n\nDataset Excerpts:\n{$contextBlock}\n\n"
        . "Task:\n"
        . "1) Give a concise explanation only from excerpts.\n"
        . "2) Mention uncertainty if excerpt is limited.\n"
        . "3) Do not say 'according to dataset/source'. Use natural Islamic phrasing.\n"
        . "4) Keep output under {$maxChars} characters.";

    $order = ['groq', 'gemini', 'openrouter', 'huggingface'];
    $attempts = [];
    foreach ($order as $provider) {
        $cfg = $providerConfig[$provider] ?? null;
        if (!is_array($cfg) || empty($cfg['active']) || trim((string)($cfg['api_key'] ?? '')) === '') {
            $attempts[] = [
                'provider' => $provider,
                'status' => 'failed',
                'model' => null,
                'latency_ms' => 0,
                'error' => 'Provider key missing or inactive'
            ];
            continue;
        }

        $model = trim((string)($cfg['model_name'] ?? ''));
        if ($model === '') {
            $model = deenai_default_model_for_provider($provider);
        }

        $start = microtime(true);
        try {
            $text = deenai_call_provider($provider, (string)$cfg['api_key'], $model, $systemPrompt, $userPrompt);
            $latency = (int)round((microtime(true) - $start) * 1000);
            $text = deenai_clean_text($text);
            if ($text === '') {
                throw new RuntimeException('Empty provider response');
            }
            if (deenai_strlen($text) > $maxChars) {
                $text = deenai_substr($text, 0, $maxChars);
            }
            $attempts[] = [
                'provider' => $provider,
                'status' => 'success',
                'model' => $model,
                'latency_ms' => $latency,
                'error' => null
            ];
            return [
                'ok' => true,
                'explanation' => $text,
                'provider' => $provider,
                'model' => $model,
                'attempts' => $attempts
            ];
        } catch (Throwable $e) {
            $attempts[] = [
                'provider' => $provider,
                'status' => 'failed',
                'model' => $model,
                'latency_ms' => (int)round((microtime(true) - $start) * 1000),
                'error' => $e->getMessage()
            ];
        }
    }

    return [
        'ok' => false,
        'explanation' => '',
        'provider' => null,
        'model' => null,
        'attempts' => $attempts
    ];
}

/**
 * Relevance ranking stage for controlled RAG.
 * LLM receives candidate snippets and returns candidate IDs only.
 */
function deenai_rank_candidates_with_fallback(
    array $providerConfig,
    string $question,
    array $candidates,
    int $topN = 3
): array {
    $topN = max(1, min(5, $topN));
    if (empty($candidates)) {
        return [
            'ok' => false,
            'ids' => [],
            'provider' => null,
            'model' => null,
            'attempts' => []
        ];
    }

    $candidateIds = [];
    $lines = [];
    foreach ($candidates as $candidate) {
        $cid = (int)($candidate['_cid'] ?? 0);
        if ($cid <= 0) {
            continue;
        }
        $candidateIds[$cid] = true;
        $reference = trim((string)($candidate['reference'] ?? ''));
        $english = trim((string)($candidate['english'] ?? ''));
        $text = trim((string)($candidate['text'] ?? ''));
        $snippet = $english !== '' ? $english : $text;
        if ($snippet === '') {
            $snippet = trim((string)($candidate['arabic'] ?? ''));
        }
        $snippet = deenai_clean_text($snippet);
        if (deenai_strlen($snippet) > 260) {
            $snippet = deenai_substr($snippet, 0, 260);
        }
        $lines[] = "ID {$cid}: {$reference} | {$snippet}";
    }

    if (empty($lines)) {
        return [
            'ok' => false,
            'ids' => [],
            'provider' => null,
            'model' => null,
            'attempts' => []
        ];
    }

    $systemPrompt = "You are a relevance ranker. "
        . "Rank candidates by relevance to the question. "
        . "Return ONLY strict JSON like {\"ids\":[3,1,2]}. "
        . "Do not return explanation text.";

    $userPrompt = "Question:\n{$question}\n\nCandidates:\n" . implode("\n", $lines)
        . "\n\nReturn the best {$topN} IDs in order of relevance.";

    $order = ['groq', 'gemini', 'openrouter', 'huggingface'];
    $attempts = [];
    foreach ($order as $provider) {
        $cfg = $providerConfig[$provider] ?? null;
        if (!is_array($cfg) || empty($cfg['active']) || trim((string)($cfg['api_key'] ?? '')) === '') {
            $attempts[] = [
                'provider' => $provider,
                'status' => 'failed',
                'model' => null,
                'latency_ms' => 0,
                'error' => 'Provider key missing or inactive'
            ];
            continue;
        }

        $model = trim((string)($cfg['model_name'] ?? ''));
        if ($model === '') {
            $model = deenai_default_model_for_provider($provider);
        }

        $start = microtime(true);
        try {
            $text = deenai_call_provider($provider, (string)$cfg['api_key'], $model, $systemPrompt, $userPrompt);
            $latency = (int)round((microtime(true) - $start) * 1000);
            $ids = deenai_extract_ranked_ids($text, array_keys($candidateIds), $topN);
            if (empty($ids)) {
                throw new RuntimeException('No ranked IDs parsed from provider');
            }
            $attempts[] = [
                'provider' => $provider,
                'status' => 'success',
                'model' => $model,
                'latency_ms' => $latency,
                'error' => null
            ];
            return [
                'ok' => true,
                'ids' => $ids,
                'provider' => $provider,
                'model' => $model,
                'attempts' => $attempts
            ];
        } catch (Throwable $e) {
            $attempts[] = [
                'provider' => $provider,
                'status' => 'failed',
                'model' => $model,
                'latency_ms' => (int)round((microtime(true) - $start) * 1000),
                'error' => $e->getMessage()
            ];
        }
    }

    return [
        'ok' => false,
        'ids' => [],
        'provider' => null,
        'model' => null,
        'attempts' => $attempts
    ];
}

function deenai_extract_ranked_ids(string $raw, array $allowedIds, int $topN): array {
    $allowed = [];
    foreach ($allowedIds as $id) {
        $allowed[(int)$id] = true;
    }

    $text = trim($raw);
    $decoded = json_decode($text, true);
    $ids = [];
    if (is_array($decoded)) {
        $arr = $decoded['ids'] ?? $decoded;
        if (is_array($arr)) {
            foreach ($arr as $v) {
                $id = (int)$v;
                if ($id > 0 && isset($allowed[$id])) {
                    $ids[] = $id;
                }
            }
        }
    }

    if (empty($ids) && preg_match_all('/\b\d+\b/', $text, $m)) {
        foreach (($m[0] ?? []) as $token) {
            $id = (int)$token;
            if ($id > 0 && isset($allowed[$id])) {
                $ids[] = $id;
            }
        }
    }

    $ids = array_values(array_unique($ids));
    if (count($ids) > $topN) {
        $ids = array_slice($ids, 0, $topN);
    }
    return $ids;
}

function deenai_default_model_for_provider(string $provider): string {
    return match (strtolower($provider)) {
        'groq' => 'llama-3.1-8b-instant',
        'gemini' => 'gemini-1.5-flash',
        'openrouter' => 'meta-llama/llama-3.1-8b-instruct:free',
        'huggingface' => 'google/flan-t5-large',
        default => 'llama-3.1-8b-instant'
    };
}

function deenai_call_provider(
    string $provider,
    string $apiKey,
    string $model,
    string $systemPrompt,
    string $userPrompt,
    int $maxTokens = 500
): string {
    $provider = strtolower($provider);
    return match ($provider) {
        'groq' => deenai_call_groq($apiKey, $model, $systemPrompt, $userPrompt, $maxTokens),
        'gemini' => deenai_call_gemini($apiKey, $model, $systemPrompt, $userPrompt, $maxTokens),
        'openrouter' => deenai_call_openrouter($apiKey, $model, $systemPrompt, $userPrompt, $maxTokens),
        'huggingface' => deenai_call_huggingface($apiKey, $model, $systemPrompt, $userPrompt, $maxTokens),
        default => throw new RuntimeException('Unsupported provider: ' . $provider)
    };
}

function deenai_call_groq(string $apiKey, string $model, string $systemPrompt, string $userPrompt, int $maxTokens = 500): string {
    $payload = [
        'model' => $model,
        'temperature' => 0.1,
        'max_tokens' => max(64, min(800, $maxTokens)),
        'messages' => [
            ['role' => 'system', 'content' => $systemPrompt],
            ['role' => 'user', 'content' => $userPrompt]
        ]
    ];
    $data = deenai_http_json_request(
        'https://api.groq.com/openai/v1/chat/completions',
        ['Authorization: Bearer ' . $apiKey],
        $payload,
        35
    );
    $text = (string)($data['choices'][0]['message']['content'] ?? '');
    if ($text === '') {
        throw new RuntimeException('Groq returned empty content');
    }
    return $text;
}

function deenai_call_gemini(string $apiKey, string $model, string $systemPrompt, string $userPrompt, int $maxTokens = 500): string {
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($apiKey);
    $payload = [
        'system_instruction' => ['parts' => [['text' => $systemPrompt]]],
        'contents' => [
            [
                'role' => 'user',
                'parts' => [['text' => $userPrompt]]
            ]
        ],
        'generationConfig' => [
            'temperature' => 0.1,
            'maxOutputTokens' => max(64, min(900, $maxTokens))
        ]
    ];
    $data = deenai_http_json_request($url, [], $payload, 35);
    $text = (string)($data['candidates'][0]['content']['parts'][0]['text'] ?? '');
    if ($text === '') {
        throw new RuntimeException('Gemini returned empty content');
    }
    return $text;
}

function deenai_call_openrouter(string $apiKey, string $model, string $systemPrompt, string $userPrompt, int $maxTokens = 500): string {
    $payload = [
        'model' => $model,
        'temperature' => 0.1,
        'max_tokens' => max(64, min(900, $maxTokens)),
        'messages' => [
            ['role' => 'system', 'content' => $systemPrompt],
            ['role' => 'user', 'content' => $userPrompt]
        ]
    ];
    $data = deenai_http_json_request(
        'https://openrouter.ai/api/v1/chat/completions',
        [
            'Authorization: Bearer ' . $apiKey,
            'HTTP-Referer: https://deenlink.local',
            'X-Title: DeenLink AI'
        ],
        $payload,
        35
    );
    $text = (string)($data['choices'][0]['message']['content'] ?? '');
    if ($text === '') {
        throw new RuntimeException('OpenRouter returned empty content');
    }
    return $text;
}

function deenai_call_huggingface(string $apiKey, string $model, string $systemPrompt, string $userPrompt, int $maxTokens = 500): string {
    $payload = [
        'inputs' => $systemPrompt . "\n\n" . $userPrompt,
        'parameters' => [
            'max_new_tokens' => max(64, min(900, $maxTokens)),
            'temperature' => 0.1,
            'return_full_text' => false
        ]
    ];
    $url = 'https://api-inference.huggingface.co/models/' . rawurlencode($model);
    $data = deenai_http_json_request(
        $url,
        ['Authorization: Bearer ' . $apiKey],
        $payload,
        45
    );

    if (isset($data[0]['generated_text'])) {
        return (string)$data[0]['generated_text'];
    }
    if (isset($data['generated_text'])) {
        return (string)$data['generated_text'];
    }
    throw new RuntimeException('Hugging Face returned unexpected payload');
}

function deenai_http_json_request(string $url, array $headers, array $payload, int $timeoutSeconds = 30): array {
    $ch = curl_init($url);
    if ($ch === false) {
        throw new RuntimeException('Unable to initialize cURL');
    }

    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) {
        throw new RuntimeException('Failed to encode request JSON');
    }

    $mergedHeaders = array_merge(
        ['Content-Type: application/json', 'Accept: application/json'],
        $headers
    );

    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => $mergedHeaders,
        CURLOPT_POSTFIELDS => $json,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => max(10, $timeoutSeconds)
    ]);

    $body = curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($body === false) {
        throw new RuntimeException('Network error: ' . $curlErr);
    }
    $decoded = json_decode($body, true);
    if ($httpCode < 200 || $httpCode >= 300) {
        $msg = is_array($decoded) ? (string)json_encode($decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : trim((string)$body);
        throw new RuntimeException("HTTP {$httpCode}: {$msg}");
    }
    if (!is_array($decoded)) {
        throw new RuntimeException('Invalid JSON response');
    }
    return $decoded;
}
