<?php
declare(strict_types=1);

require_once __DIR__ . '/common.php';

function deenai_select_best_dataset(PDO $pdo, array $intentCtx): ?array {
    $ranked = deenai_select_ranked_datasets($pdo, $intentCtx, 1);
    return $ranked[0] ?? null;
}

function deenai_select_ranked_datasets(PDO $pdo, array $intentCtx, int $max = 6): array {
    $types = $intentCtx['types'] ?? [];
    if (!is_array($types) || empty($types)) {
        return [];
    }

    $max = max(1, min(20, $max));
    $placeholders = implode(',', array_fill(0, count($types), '?'));
    $sql = "
        SELECT id, name, type, storage_type, file_path, keywords, description, active
        FROM datasets
        WHERE active = 1
          AND type IN ($placeholders)
        ORDER BY id DESC
    ";
    $st = $pdo->prepare($sql);
    $st->execute(array_values($types));
    $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    if (!$rows) {
        return [];
    }

    $query = deenai_lower((string)($intentCtx['query'] ?? ''));
    $tokens = is_array($intentCtx['tokens'] ?? null) ? (array)$intentCtx['tokens'] : [];
    $intent = (string)($intentCtx['intent'] ?? '');
    $explicitLock = !empty($intentCtx['explicit_type_lock']);
    $typePriority = array_flip(array_values($types));

    $scored = [];
    foreach ($rows as $row) {
        $type = deenai_lower((string)($row['type'] ?? ''));
        $priorityIndex = isset($typePriority[$type]) ? (int)$typePriority[$type] : 99;
        $score = max(0, 120 - ($priorityIndex * 15));
        $hay = deenai_lower(trim((string)$row['name'] . ' ' . (string)$row['keywords'] . ' ' . (string)$row['description']));

        foreach ($tokens as $t) {
            $needle = deenai_lower((string)$t);
            if ($needle !== '' && str_contains($hay, $needle)) {
                $score += 5;
            }
        }

        if ($query !== '' && str_contains($hay, $query)) {
            $score += 10;
        }
        if ($intent === 'quran_ayah_lookup' && $type === 'quran') {
            $score += 20;
        }
        if ($intent === 'hadith_lookup' && $type === 'hadith') {
            $score += 20;
        }
        if ($intent === 'dua_adhkar_lookup' && ($type === 'dua' || $type === 'adhkar')) {
            $score += 20;
        }
        if ($intent === 'asmaulhusna_lookup' && $type === 'asmaulhusna') {
            $score += 20;
        }
        if ($explicitLock && $priorityIndex === 0) {
            $score += 30;
        }

        $row['_score'] = $score;
        $row['_priority'] = $priorityIndex;
        $scored[] = $row;
    }

    usort($scored, static function (array $a, array $b): int {
        $cmp = ((int)$b['_score']) <=> ((int)$a['_score']);
        if ($cmp !== 0) {
            return $cmp;
        }
        $cmp = ((int)$a['_priority']) <=> ((int)$b['_priority']);
        if ($cmp !== 0) {
            return $cmp;
        }
        return ((int)$b['id']) <=> ((int)$a['id']);
    });

    $scored = array_slice($scored, 0, $max);
    foreach ($scored as &$row) {
        unset($row['_score'], $row['_priority']);
    }
    unset($row);
    return array_values($scored);
}

function deenai_retrieve_content(PDO $pdo, array $dataset, array $intentCtx, int $limit = 5): array {
    $limit = max(1, min(20, $limit));
    $storage = strtolower((string)($dataset['storage_type'] ?? 'json'));
    if ($storage === 'txt') {
        return deenai_retrieve_txt_content($pdo, $dataset, $intentCtx, $limit);
    }
    return deenai_retrieve_json_content($dataset, $intentCtx, $limit);
}

function deenai_resolve_local_path(string $configuredPath): ?string {
    $configuredPath = trim($configuredPath);
    if ($configuredPath === '') {
        return null;
    }

    $root = deenai_project_root();
    $rootReal = realpath($root);
    if ($rootReal === false) {
        return null;
    }

    $candidate = $configuredPath;
    if (!preg_match('/^[a-zA-Z]:[\\\\\\/]/', $configuredPath) && !str_starts_with($configuredPath, '/')) {
        $candidate = $root . DIRECTORY_SEPARATOR . ltrim(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $configuredPath), DIRECTORY_SEPARATOR);
    }

    $real = realpath($candidate);
    if ($real === false) {
        return null;
    }
    // Local-only safety: dataset files must be inside project root.
    if (!str_starts_with(str_replace('\\', '/', $real), str_replace('\\', '/', $rootReal))) {
        return null;
    }
    return $real;
}

function deenai_retrieve_json_content(array $dataset, array $intentCtx, int $limit): array {
    $realPath = deenai_resolve_local_path((string)($dataset['file_path'] ?? ''));
    if ($realPath === null) {
        return [];
    }

    $type = strtolower((string)($dataset['type'] ?? ''));
    if ($type === 'quran') {
        return deenai_retrieve_quran($realPath, $intentCtx, $limit);
    }
    if ($type === 'hadith') {
        return deenai_retrieve_hadith($realPath, $intentCtx, $limit);
    }
    if ($type === 'dua' || $type === 'adhkar') {
        return deenai_retrieve_dua_adhkar($realPath, $intentCtx, $limit);
    }
    if ($type === 'asmaulhusna') {
        return deenai_retrieve_asmaulhusna($realPath, $intentCtx, $limit);
    }
    if ($type === 'story' || $type === 'book') {
        return deenai_retrieve_story_json($realPath, $intentCtx, $limit);
    }
    return deenai_retrieve_generic_json($realPath, $intentCtx, $limit);
}

function deenai_retrieve_story_json(string $realPath, array $intentCtx, int $limit): array {
    $files = deenai_collect_json_files($realPath);
    if (!$files) {
        return [];
    }

    $query = deenai_normalize_query_text((string)($intentCtx['query'] ?? ''));
    $tokens = is_array($intentCtx['tokens'] ?? null) ? (array)$intentCtx['tokens'] : [];
    $rows = [];

    foreach ($files as $file) {
        $fh = @fopen($file, 'r');
        if (!is_resource($fh)) {
            continue;
        }
        while (($line = fgets($fh)) !== false) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $obj = json_decode($line, true);
            if (!is_array($obj)) {
                continue;
            }

            $title = deenai_clean_text((string)($obj['title'] ?? ''));
            $details = deenai_clean_text((string)($obj['details'] ?? ''));
            if ($title === '' && $details === '') {
                continue;
            }

            $year = trim((string)($obj['gregorian_year'] ?? ''));
            $hijriYear = trim((string)($obj['hijri_year'] ?? ''));
            $location = deenai_clean_text((string)($obj['location_name'] ?? ''));
            $source = trim((string)($obj['source_url'] ?? ''));
            $id = trim((string)($obj['event_id'] ?? ''));

            $hay = deenai_lower(trim($title . ' ' . $details . ' ' . $location . ' ' . $year . ' ' . $hijriYear));
            $score = 0;
            if ($query !== '' && str_contains($hay, deenai_lower($query))) {
                $score += 16;
            }
            foreach ($tokens as $tok) {
                $needle = deenai_lower((string)$tok);
                if ($needle === '' || deenai_strlen($needle) < 3) {
                    continue;
                }
                if (str_contains($hay, $needle)) {
                    $score += 4;
                }
            }
            if ($score <= 0) {
                continue;
            }

            $referenceParts = [];
            if ($id !== '') {
                $referenceParts[] = 'Event #' . $id;
            }
            if ($year !== '') {
                $referenceParts[] = 'CE ' . $year;
            }
            if ($hijriYear !== '') {
                $referenceParts[] = 'Hijri ' . $hijriYear;
            }
            if ($location !== '') {
                $referenceParts[] = $location;
            }
            $reference = !empty($referenceParts) ? implode(' | ', $referenceParts) : basename($file);
            if ($source !== '') {
                $reference .= ' | ' . $source;
            }

            $text = $title;
            if ($details !== '') {
                $text .= "\n\n" . $details;
            }

            $rows[] = [
                'score' => $score,
                'item' => [
                    'english' => $text,
                    'text' => $text,
                    'reference' => $reference,
                    'type' => 'story',
                    'confidence_score' => $score
                ]
            ];
        }
        fclose($fh);
    }

    usort($rows, static fn(array $a, array $b): int => $b['score'] <=> $a['score']);
    $out = [];
    foreach ($rows as $row) {
        $out[] = $row['item'];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function deenai_retrieve_quran(string $realPath, array $intentCtx, int $limit): array {
    $surah = (int)($intentCtx['surah'] ?? 0);
    $ayah = (int)($intentCtx['ayah'] ?? 0);
    $intent = (string)($intentCtx['intent'] ?? '');
    $tokens = $intentCtx['tokens'] ?? [];

    if ($surah > 0) {
        $file = is_dir($realPath)
            ? $realPath . DIRECTORY_SEPARATOR . 'surah_' . $surah . '.json'
            : $realPath;
        if (!is_file($file)) {
            return [];
        }
        $data = deenai_json_file_to_array($file);
        if (!is_array($data) || !isset($data['verses']) || !is_array($data['verses'])) {
            return [];
        }

        if ($intent === 'quran_ayah_count') {
            $count = count($data['verses']);
            $ref = deenai_quran_reference($surah, 0);
            return [[
                'text' => "{$ref} has {$count} ayahs in this local dataset.",
                'reference' => $ref,
                'type' => 'quran_count',
                'confidence_score' => 100
            ]];
        }

        $items = [];
        foreach ($data['verses'] as $verse) {
            $verseNo = (int)($verse['ayah'] ?? 0);
            if ($ayah > 0 && $verseNo !== $ayah) {
                continue;
            }
            $arabic = trim((string)($verse['arabic'] ?? ''));
            $english = trim((string)($verse['english'] ?? ''));
            if ($arabic === '' && $english === '') {
                continue;
            }
            $items[] = [
                'arabic' => $arabic,
                'english' => $english,
                'reference' => deenai_quran_reference($surah, $verseNo),
                'type' => 'quran_ayah',
                'confidence_score' => 100
            ];
            if (count($items) >= $limit) {
                break;
            }
        }
        return $items;
    }

    $files = deenai_collect_json_files($realPath);
    if (!$files) {
        return [];
    }
    $scored = [];
    foreach ($files as $file) {
        $data = deenai_json_file_to_array($file);
        if (!is_array($data) || !isset($data['verses']) || !is_array($data['verses'])) {
            continue;
        }
        $surahNo = (int)($data['surah'] ?? 0);
        foreach ($data['verses'] as $verse) {
            $arabic = trim((string)($verse['arabic'] ?? ''));
            $english = trim((string)($verse['english'] ?? ''));
            $hay = deenai_lower($english . ' ' . $arabic);
            $score = 0;
            foreach ($tokens as $tok) {
                $needle = deenai_lower((string)$tok);
                if ($needle !== '' && str_contains($hay, $needle)) {
                    $score += 2;
                }
            }
            if ($score <= 0) {
                continue;
            }
            $scored[] = [
                'score' => $score,
                'item' => [
                    'arabic' => $arabic,
                    'english' => $english,
                    'reference' => deenai_quran_reference($surahNo, (int)($verse['ayah'] ?? 0)),
                    'type' => 'quran_ayah',
                    'confidence_score' => $score
                ]
            ];
        }
    }

    usort($scored, static fn(array $a, array $b): int => $b['score'] <=> $a['score']);
    $out = [];
    foreach ($scored as $row) {
        $out[] = $row['item'];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function deenai_retrieve_hadith(string $realPath, array $intentCtx, int $limit): array {
    $tokens = $intentCtx['tokens'] ?? [];
    $query = deenai_normalize_query_text((string)($intentCtx['query'] ?? ''));
    $files = deenai_collect_json_files($realPath);
    if (!$files) {
        return [];
    }

    $collectionFile = deenai_pick_hadith_collection_file($realPath, $query);
    if ($collectionFile !== null) {
        $files = [$collectionFile];
    }

    $rows = [];
    $scanned = 0;
    $maxScan = 9000;
    foreach ($files as $file) {
        $data = deenai_json_file_to_array($file);
        if (!is_array($data)) {
            continue;
        }
        foreach ($data as $entry) {
            $scanned++;
            if ($scanned > $maxScan) {
                break 2;
            }
            if (!is_array($entry)) {
                continue;
            }
            $englishText = deenai_pick_hadith_english($entry);
            $arabic = trim((string)($entry['arabic'] ?? ''));
            if ($englishText === '' && $arabic === '') {
                continue;
            }

            $chapterName = '';
            if (isset($entry['chapter_name']) && is_array($entry['chapter_name'])) {
                $chapterName = (string)($entry['chapter_name']['english'] ?? '');
            }
            $collection = trim((string)($entry['collection'] ?? pathinfo($file, PATHINFO_FILENAME)));
            $hadithNumber = trim((string)($entry['hadith_number'] ?? ''));

            $hay = deenai_lower($englishText . ' ' . $arabic . ' ' . $chapterName . ' ' . $collection);
            $score = 0;
            foreach ($tokens as $tok) {
                $needle = deenai_lower((string)$tok);
                if ($needle !== '' && str_contains($hay, $needle)) {
                    $score += 2;
                }
            }
            if ($hadithNumber !== '' && str_contains($query, $hadithNumber)) {
                $score += 4;
            }
            if ($score <= 0) {
                continue;
            }
            $ref = ucfirst($collection);
            if ($hadithNumber !== '') {
                $ref .= ' #' . $hadithNumber;
            }
            if ($chapterName !== '') {
                $ref .= ' - ' . $chapterName;
            }

            $rows[] = [
                'score' => $score,
                'item' => [
                    'arabic' => $arabic,
                    'english' => $englishText,
                    'reference' => $ref,
                    'type' => 'hadith',
                    'confidence_score' => $score
                ]
            ];
        }
    }

    usort($rows, static fn(array $a, array $b): int => $b['score'] <=> $a['score']);
    $out = [];
    foreach ($rows as $row) {
        $out[] = $row['item'];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function deenai_pick_hadith_collection_file(string $realPath, string $queryLower): ?string {
    if (!is_dir($realPath)) {
        return null;
    }
    $map = [
        'bukhari' => 'buhari.json',
        'buhari' => 'buhari.json',
        'muslim' => 'muslim.json',
        'tirmidhi' => 'tirmidhi.json',
        'abu dawud' => 'abudawud.json',
        'abudawud' => 'abudawud.json',
        'ibn majah' => 'ibnmajah.json',
        'nawawi' => 'nawawi40.json',
        'nawawi 40' => 'nawawi40.json',
        'riyad' => 'riyad_assalihin.json',
        'nasai' => 'nasai.json',
        'ahmad' => 'ahmed.json',
        'malik' => 'malik.json'
    ];
    foreach ($map as $needle => $fileName) {
        if (!str_contains($queryLower, $needle)) {
            continue;
        }
        $full = $realPath . DIRECTORY_SEPARATOR . $fileName;
        if (is_file($full)) {
            return $full;
        }
    }
    return null;
}

function deenai_pick_hadith_english(array $entry): string {
    $english = $entry['english'] ?? '';
    if (is_string($english)) {
        return trim($english);
    }
    if (is_array($english)) {
        $narrator = trim((string)($english['narrator'] ?? ''));
        $text = trim((string)($english['text'] ?? ''));
        return trim($narrator . ' ' . $text);
    }
    return '';
}

function deenai_retrieve_dua_adhkar(string $realPath, array $intentCtx, int $limit): array {
    $data = deenai_json_file_to_array($realPath);
    if (!is_array($data)) {
        return [];
    }

    $query = deenai_normalize_query_text((string)($intentCtx['query'] ?? ''));
    $tokens = $intentCtx['tokens'] ?? [];
    $classification = (string)($intentCtx['classification'] ?? '');
    $rows = [];

    $collections = [];
    if (isset($data['English']) && is_array($data['English'])) {
        $collections = $data['English'];
    } elseif (isset($data['data']) && is_array($data['data'])) {
        $collections = $data['data'];
    } elseif (isset($data[0]) && is_array($data)) {
        $collections = $data;
    }

    foreach ($collections as $group) {
        if (!is_array($group)) {
            continue;
        }
        $title = trim((string)($group['TITLE'] ?? $group['title'] ?? 'Supplication'));
        $items = $group['TEXT'] ?? $group['text'] ?? $group['items'] ?? [];
        if (!is_array($items)) {
            continue;
        }

        foreach ($items as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $arabic = trim((string)($entry['ARABIC_TEXT'] ?? $entry['arabic'] ?? ''));
            $english = trim((string)($entry['TRANSLATED_TEXT'] ?? $entry['translation'] ?? ''));
            if ($english === '') {
                $english = trim((string)($entry['LANGUAGE_ARABIC_TRANSLATED_TEXT'] ?? ''));
            }
            $reference = $title;
            $id = trim((string)($entry['ID'] ?? $entry['id'] ?? ''));
            if ($id !== '') {
                $reference .= ' #' . $id;
            }

            $hay = deenai_lower($title . ' ' . $english . ' ' . $arabic);
            $score = 0;
            foreach ($tokens as $tok) {
                $needle = deenai_lower((string)$tok);
                if ($needle !== '' && str_contains($hay, $needle)) {
                    $score += 2;
                }
            }

            // Guidance recommendation boosts.
            if ($classification === 'guidance') {
                $score += 2;
                if (str_contains($query, 'before sleep') || str_contains($query, 'before bed') || str_contains($query, 'going to bed')) {
                    if (str_contains($hay, 'sleep') || str_contains($hay, 'bed') || str_contains($hay, 'night')) {
                        $score += 5;
                    }
                }
                if (str_contains($query, 'morning') || str_contains($query, 'evening')) {
                    if (str_contains($hay, 'morning') || str_contains($hay, 'evening')) {
                        $score += 4;
                    }
                }
                if (str_contains($query, 'fear') || str_contains($query, 'afraid') || str_contains($query, 'protection')) {
                    if (str_contains($hay, 'refuge') || str_contains($hay, 'protect') || str_contains($hay, 'safety')) {
                        $score += 4;
                    }
                }
                if (str_contains($query, 'forgive') || str_contains($query, 'forgiveness') || str_contains($query, 'sin')) {
                    if (str_contains($hay, 'forgive') || str_contains($hay, 'repent') || str_contains($hay, 'mercy')) {
                        $score += 4;
                    }
                }
                if (str_contains($query, 'anxiety') || str_contains($query, 'worry') || str_contains($query, 'stress')) {
                    if (str_contains($hay, 'peace') || str_contains($hay, 'calm') || str_contains($hay, 'heart')) {
                        $score += 3;
                    }
                }
                if (str_contains($query, 'patience') || str_contains($query, 'sabr')) {
                    if (str_contains($hay, 'patience') || str_contains($hay, 'sabr')) {
                        $score += 3;
                    }
                }
                if (str_contains($query, 'before eating') || str_contains($query, 'before food') || str_contains($query, 'eat') || str_contains($query, 'eating')) {
                    if (str_contains($hay, 'eat') || str_contains($hay, 'food') || str_contains($hay, 'meal') || str_contains($hay, 'bismillah')) {
                        $score += 6;
                    }
                }
                if (str_contains($query, 'after eating') || str_contains($query, 'after food')) {
                    if (str_contains($hay, 'after') && (str_contains($hay, 'eat') || str_contains($hay, 'food') || str_contains($hay, 'meal'))) {
                        $score += 6;
                    }
                }
                if (str_contains($query, 'sad') || str_contains($query, 'lonely') || str_contains($query, 'grief')) {
                    if (str_contains($hay, 'sad') || str_contains($hay, 'distress') || str_contains($hay, 'sorrow') || str_contains($hay, 'lonely')) {
                        $score += 5;
                    }
                }
                if (str_contains($query, 'travel')) {
                    if (str_contains($hay, 'travel') || str_contains($hay, 'journey') || str_contains($hay, 'safar')) {
                        $score += 5;
                    }
                }
            }

            if ($score <= 0 && str_contains($hay, deenai_lower($query))) {
                $score = 2;
            }
            if ($score <= 0) {
                continue;
            }
            $rows[] = [
                'score' => $score,
                'item' => [
                    'arabic' => $arabic,
                    'english' => $english,
                    'reference' => $reference,
                    'type' => 'dua',
                    'confidence_score' => $score
                ]
            ];
        }
    }

    usort($rows, static fn(array $a, array $b): int => $b['score'] <=> $a['score']);
    $out = [];
    foreach ($rows as $row) {
        $out[] = $row['item'];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function deenai_retrieve_asmaulhusna(string $realPath, array $intentCtx, int $limit): array {
    $data = deenai_json_file_to_array($realPath);
    if (!is_array($data)) {
        return [];
    }
    $names = [];
    if (isset($data['data']['names']) && is_array($data['data']['names'])) {
        $names = $data['data']['names'];
    } elseif (isset($data['names']) && is_array($data['names'])) {
        $names = $data['names'];
    } elseif (isset($data[0]) && is_array($data)) {
        $names = $data;
    }
    if (!$names) {
        return [];
    }

    $tokens = $intentCtx['tokens'] ?? [];
    $query = deenai_normalize_query_text((string)($intentCtx['query'] ?? ''));
    $rows = [];

    foreach ($names as $entry) {
        if (!is_array($entry)) {
            continue;
        }
        $arabic = trim((string)($entry['name'] ?? $entry['arabic'] ?? ''));
        $translit = trim((string)($entry['transliteration'] ?? ''));
        $translation = trim((string)($entry['translation'] ?? ''));
        $meaning = trim((string)($entry['meaning'] ?? ''));
        $reference = $translit !== '' ? $translit : ('Name #' . (string)($entry['number'] ?? ''));
        $english = trim($translit . ' - ' . $translation . '. ' . $meaning);

        $hay = deenai_lower($arabic . ' ' . $english);
        $score = 0;
        foreach ($tokens as $tok) {
            $needle = deenai_lower((string)$tok);
            if ($needle !== '' && str_contains($hay, $needle)) {
                $score += 2;
            }
        }
        if (str_contains($query, 'mercy') && (str_contains($hay, 'merciful') || str_contains($hay, 'compassion'))) {
            $score += 3;
        }
        if (str_contains($query, 'forgive') && str_contains($hay, 'forgiv')) {
            $score += 3;
        }
        if ($score <= 0) {
            continue;
        }

        $rows[] = [
            'score' => $score,
            'item' => [
                'arabic' => $arabic,
                'english' => $english,
                'reference' => $reference,
                'type' => 'asmaulhusna',
                'confidence_score' => $score
            ]
        ];
    }

    usort($rows, static fn(array $a, array $b): int => $b['score'] <=> $a['score']);
    $out = [];
    foreach ($rows as $row) {
        $out[] = $row['item'];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function deenai_retrieve_generic_json(string $realPath, array $intentCtx, int $limit): array {
    $tokens = $intentCtx['tokens'] ?? [];
    $files = deenai_collect_json_files($realPath);
    if (!$files) {
        return [];
    }
    $scored = [];
    foreach ($files as $file) {
        $data = deenai_json_file_to_array($file);
        if (!is_array($data)) {
            continue;
        }
        $flattened = deenai_flatten_json_strings($data);
        foreach ($flattened as $str) {
            $hay = deenai_lower($str);
            $score = 0;
            foreach ($tokens as $tok) {
                $needle = deenai_lower((string)$tok);
                if ($needle !== '' && str_contains($hay, $needle)) {
                    $score += 1;
                }
            }
            if ($score <= 0) {
                continue;
            }
            $scored[] = [
                'score' => $score,
                'item' => [
                    'text' => $str,
                    'reference' => basename($file),
                    'type' => 'generic_json'
                ]
            ];
        }
    }
    usort($scored, static fn(array $a, array $b): int => $b['score'] <=> $a['score']);
    $out = [];
    foreach ($scored as $row) {
        $out[] = $row['item'];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function deenai_retrieve_txt_content(PDO $pdo, array $dataset, array $intentCtx, int $limit): array {
    $realPath = deenai_resolve_local_path((string)($dataset['file_path'] ?? ''));
    if ($realPath === null || !is_file($realPath)) {
        return [];
    }

    $indexed = deenai_retrieve_txt_qa_from_index($pdo, $dataset, $intentCtx, $limit, $realPath);
    if (is_array($indexed)) {
        return $indexed;
    }

    $raw = file_get_contents($realPath);
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $tokens = is_array($intentCtx['tokens'] ?? null) ? (array)$intentCtx['tokens'] : [];
    $datasetId = (int)($dataset['id'] ?? 0);

    // Structured QA parser for islamqa-style txt datasets.
    if (deenai_txt_looks_like_qa_blocks($raw)) {
        $entries = deenai_parse_txt_qa_blocks($raw);
        deenai_sync_txt_qa_index($pdo, $dataset, $realPath, $raw, $entries);
        return deenai_retrieve_txt_qa_rows($entries, $intentCtx, $limit);
    }

    $sections = [];
    if ($datasetId > 0) {
        $st = $pdo->prepare("
            SELECT section_title, start_marker, end_marker
            FROM dataset_sections
            WHERE dataset_id = ?
            ORDER BY id ASC
        ");
        $st->execute([$datasetId]);
        $sections = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    $candidates = [];
    if ($sections) {
        $lowerRaw = deenai_lower($raw);
        foreach ($sections as $section) {
            $title = trim((string)($section['section_title'] ?? ''));
            $start = trim((string)($section['start_marker'] ?? ''));
            $end = trim((string)($section['end_marker'] ?? ''));
            if ($start === '') {
                continue;
            }
            $startPos = deenai_stripos($lowerRaw, deenai_lower($start), 0);
            if ($startPos === false) {
                continue;
            }
            $sliceStart = (int)$startPos;
            $sliceLen = 1500;
            if ($end !== '') {
                $endPos = deenai_stripos($lowerRaw, deenai_lower($end), $sliceStart + 1);
                if ($endPos !== false && (int)$endPos > $sliceStart) {
                    $sliceLen = (int)$endPos - $sliceStart;
                }
            }
            $snippet = trim(deenai_substr($raw, $sliceStart, $sliceLen));
            if ($snippet === '') {
                continue;
            }
            $candidates[] = [
                'reference' => $title !== '' ? $title : 'Section',
                'text' => $snippet
            ];
        }
    }

    if (!$candidates) {
        $chunks = preg_split('/\R{2,}/u', $raw) ?: [];
        foreach ($chunks as $idx => $chunk) {
            $chunk = trim((string)$chunk);
            if ($chunk === '') {
                continue;
            }
            $candidates[] = [
                'reference' => 'Paragraph ' . ($idx + 1),
                'text' => $chunk
            ];
        }
    }

    $scored = [];
    foreach ($candidates as $candidate) {
        $hay = deenai_lower($candidate['text']);
        $score = 0;
        foreach ($tokens as $tok) {
            $needle = deenai_lower((string)$tok);
            if ($needle !== '' && str_contains($hay, $needle)) {
                $score += 2;
            }
        }
        if ($score <= 0) {
            continue;
        }
        $scored[] = ['score' => $score, 'item' => [
            'text' => $candidate['text'],
            'reference' => $candidate['reference'],
            'type' => 'txt_section'
        ]];
    }
    usort($scored, static fn(array $a, array $b): int => $b['score'] <=> $a['score']);
    $out = [];
    foreach ($scored as $row) {
        $out[] = $row['item'];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function deenai_txt_looks_like_qa_blocks(string $raw): bool {
    $lower = deenai_lower($raw);
    return str_contains($lower, 'id:')
        && str_contains($lower, 'question:')
        && str_contains($lower, 'answer:')
        && str_contains($lower, 'source:');
}

function deenai_retrieve_txt_qa_blocks(string $raw, array $intentCtx, int $limit): array {
    $entries = deenai_parse_txt_qa_blocks($raw);
    return deenai_retrieve_txt_qa_rows($entries, $intentCtx, $limit);
}

function deenai_retrieve_txt_qa_rows(array $entries, array $intentCtx, int $limit): array {
    if (empty($entries)) {
        return [];
    }

    $query = deenai_lower((string)($intentCtx['query'] ?? ''));
    $tokens = is_array($intentCtx['tokens'] ?? null) ? (array)$intentCtx['tokens'] : [];
    $classification = (string)($intentCtx['classification'] ?? '');
    $rows = [];

    foreach ($entries as $entry) {
        $questionText = (string)($entry['question'] ?? '');
        $answerText = (string)($entry['answer'] ?? '');
        $category = deenai_lower((string)($entry['category'] ?? ''));
        if ($questionText === '' || $answerText === '') {
            continue;
        }

        $qHay = deenai_lower($questionText);
        $aHay = deenai_lower($answerText);
        $score = 0;

        if ($query !== '' && str_contains($qHay, $query)) {
            $score += 16;
        }
        if ($query !== '' && str_contains($aHay, $query)) {
            $score += 6;
        }

        foreach ($tokens as $tok) {
            $needle = deenai_lower((string)$tok);
            if ($needle === '') {
                continue;
            }
            if (str_contains($qHay, $needle)) {
                $score += 4;
            }
            if (str_contains($aHay, $needle)) {
                $score += 1;
            }
            if ($category !== '' && str_contains($category, $needle)) {
                $score += 2;
            }
        }

        if ($classification === 'personal_verdict' && (str_contains($category, 'fatwa') || str_contains($category, 'fiqh'))) {
            $score += 4;
        }

        if ($score <= 0) {
            continue;
        }

        $id = trim((string)($entry['id'] ?? ''));
        $source = trim((string)($entry['source'] ?? ''));
        $reference = 'Dataset QA';
        if ($id !== '') {
            $reference = 'IslamQA ' . $id;
        }
        if ($source !== '') {
            $reference .= ' (' . $source . ')';
        }

        $rows[] = [
            'score' => $score,
            'item' => [
                'english' => $answerText,
                'text' => 'Question: ' . $questionText . "\n\nAnswer: " . $answerText,
                'reference' => $reference,
                'type' => 'txt_qa',
                'question' => $questionText,
                'confidence_score' => $score
            ]
        ];
    }

    usort($rows, static fn(array $a, array $b): int => $b['score'] <=> $a['score']);
    $out = [];
    foreach ($rows as $row) {
        $out[] = $row['item'];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function deenai_txt_qa_score_entry(array $entry, string $query, array $tokens, string $classification): int {
    $questionText = (string)($entry['question'] ?? '');
    $answerText = (string)($entry['answer'] ?? '');
    $category = deenai_lower((string)($entry['category'] ?? ''));
    if ($questionText === '' || $answerText === '') {
        return 0;
    }

    $qHay = deenai_lower($questionText);
    $aHay = deenai_lower($answerText);
    $score = 0;

    if ($query !== '' && str_contains($qHay, $query)) {
        $score += 16;
    }
    if ($query !== '' && str_contains($aHay, $query)) {
        $score += 6;
    }

    foreach ($tokens as $tok) {
        $needle = deenai_lower((string)$tok);
        if ($needle === '') {
            continue;
        }
        if (str_contains($qHay, $needle)) {
            $score += 4;
        }
        if (str_contains($aHay, $needle)) {
            $score += 1;
        }
        if ($category !== '' && str_contains($category, $needle)) {
            $score += 2;
        }
    }

    if ($classification === 'personal_verdict' && (str_contains($category, 'fatwa') || str_contains($category, 'fiqh'))) {
        $score += 4;
    }
    return $score;
}

function deenai_retrieve_txt_qa_from_index(PDO $pdo, array $dataset, array $intentCtx, int $limit, string $realPath): ?array {
    $datasetId = (int)($dataset['id'] ?? 0);
    if ($datasetId <= 0) {
        return null;
    }

    $fileHash = @hash_file('sha256', $realPath);
    if (!is_string($fileHash) || $fileHash === '') {
        return null;
    }

    $stState = $pdo->prepare("
        SELECT file_hash, entry_count
        FROM ai_dataset_index_state
        WHERE dataset_id = ?
        LIMIT 1
    ");
    $stState->execute([$datasetId]);
    $state = $stState->fetch(PDO::FETCH_ASSOC);
    if (!is_array($state)) {
        return null;
    }
    if ((string)($state['file_hash'] ?? '') !== $fileHash || (int)($state['entry_count'] ?? 0) <= 0) {
        return null;
    }

    $query = deenai_lower((string)($intentCtx['query'] ?? ''));
    $tokens = is_array($intentCtx['tokens'] ?? null) ? (array)$intentCtx['tokens'] : [];
    $classification = (string)($intentCtx['classification'] ?? '');
    $booleanQuery = deenai_build_boolean_search_query($tokens);

    $rows = [];
    if ($booleanQuery !== '') {
        $st = $pdo->prepare("
            SELECT entry_key, category, question, answer, source,
                   MATCH(question, answer, search_text) AGAINST (? IN BOOLEAN MODE) AS ft_score
            FROM ai_dataset_entries
            WHERE dataset_id = ?
            ORDER BY ft_score DESC, id ASC
            LIMIT 120
        ");
        $st->execute([$booleanQuery, $datasetId]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    if (empty($rows) && $query !== '') {
        $st = $pdo->prepare("
            SELECT entry_key, category, question, answer, source,
                   MATCH(question, answer, search_text) AGAINST (? IN NATURAL LANGUAGE MODE) AS ft_score
            FROM ai_dataset_entries
            WHERE dataset_id = ?
            ORDER BY ft_score DESC, id ASC
            LIMIT 120
        ");
        $st->execute([$query, $datasetId]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    if (empty($rows) && !empty($tokens)) {
        $firstToken = '';
        foreach ($tokens as $tok) {
            $tok = trim((string)$tok);
            if (deenai_strlen($tok) >= 3) {
                $firstToken = $tok;
                break;
            }
        }
        if ($firstToken !== '') {
            $like = '%' . $firstToken . '%';
            $st = $pdo->prepare("
                SELECT entry_key, category, question, answer, source, 0 AS ft_score
                FROM ai_dataset_entries
                WHERE dataset_id = ?
                  AND (question LIKE ? OR answer LIKE ? OR search_text LIKE ?)
                ORDER BY id ASC
                LIMIT 180
            ");
            $st->execute([$datasetId, $like, $like, $like]);
            $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
        }
    }

    if (empty($rows)) {
        return [];
    }

    $scored = [];
    foreach ($rows as $row) {
        $entry = [
            'id' => (string)($row['entry_key'] ?? ''),
            'category' => (string)($row['category'] ?? ''),
            'question' => (string)($row['question'] ?? ''),
            'answer' => (string)($row['answer'] ?? ''),
            'source' => (string)($row['source'] ?? '')
        ];
        $score = deenai_txt_qa_score_entry($entry, $query, $tokens, $classification);
        $score += (int)round(((float)($row['ft_score'] ?? 0)) * 8);
        if ($score <= 0) {
            continue;
        }
        $id = trim((string)$entry['id']);
        $source = trim((string)$entry['source']);
        $reference = 'Dataset QA';
        if ($id !== '') {
            $reference = 'IslamQA ' . $id;
        }
        if ($source !== '') {
            $reference .= ' (' . $source . ')';
        }

        $scored[] = [
            'score' => $score,
            'item' => [
                'english' => (string)$entry['answer'],
                'text' => 'Question: ' . (string)$entry['question'] . "\n\nAnswer: " . (string)$entry['answer'],
                'reference' => $reference,
                'type' => 'txt_qa',
                'question' => (string)$entry['question'],
                'confidence_score' => $score
            ]
        ];
    }

    usort($scored, static fn(array $a, array $b): int => $b['score'] <=> $a['score']);
    $out = [];
    foreach ($scored as $row) {
        $out[] = $row['item'];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function deenai_build_boolean_search_query(array $tokens): string {
    $parts = [];
    foreach ($tokens as $tok) {
        $tok = deenai_lower((string)$tok);
        $tok = preg_replace('/[^a-z0-9\p{L}]+/u', '', $tok) ?? '';
        if ($tok === '' || deenai_strlen($tok) < 3) {
            continue;
        }
        $parts[] = '+' . $tok . '*';
        if (count($parts) >= 8) {
            break;
        }
    }
    return trim(implode(' ', $parts));
}

function deenai_sync_txt_qa_index(PDO $pdo, array $dataset, string $realPath, string $raw, array $entries): void {
    $datasetId = (int)($dataset['id'] ?? 0);
    if ($datasetId <= 0 || empty($entries)) {
        return;
    }

    $fileHash = hash('sha256', $raw);
    $stState = $pdo->prepare("
        SELECT file_hash, entry_count
        FROM ai_dataset_index_state
        WHERE dataset_id = ?
        LIMIT 1
    ");
    $stState->execute([$datasetId]);
    $state = $stState->fetch(PDO::FETCH_ASSOC);
    if (is_array($state) && (string)($state['file_hash'] ?? '') === $fileHash && (int)($state['entry_count'] ?? 0) > 0) {
        return;
    }

    $pdo->beginTransaction();
    try {
        $del = $pdo->prepare("DELETE FROM ai_dataset_entries WHERE dataset_id = ?");
        $del->execute([$datasetId]);

        $ins = $pdo->prepare("
            INSERT INTO ai_dataset_entries
                (dataset_id, entry_key, category, question, answer, source, search_text, entry_hash, created_at, updated_at)
            VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ");

        $count = 0;
        foreach ($entries as $idx => $entry) {
            $id = deenai_clean_text((string)($entry['id'] ?? ''));
            $category = deenai_clean_text((string)($entry['category'] ?? ''));
            $question = deenai_clean_text((string)($entry['question'] ?? ''));
            $answer = deenai_clean_text((string)($entry['answer'] ?? ''));
            $source = deenai_clean_text((string)($entry['source'] ?? ''));
            if ($question === '' || $answer === '') {
                continue;
            }

            $entryKey = $id !== '' ? $id : ('row_' . ($idx + 1));
            $searchText = trim($category . ' ' . $question . ' ' . $answer . ' ' . $source);
            $entryHash = sha1($entryKey . '|' . $question . '|' . $answer . '|' . $source);

            $ins->execute([
                $datasetId,
                $entryKey,
                $category !== '' ? $category : null,
                $question,
                $answer,
                $source !== '' ? $source : null,
                $searchText,
                $entryHash
            ]);
            $count++;
        }

        $up = $pdo->prepare("
            INSERT INTO ai_dataset_index_state (dataset_id, file_hash, indexed_at, entry_count)
            VALUES (?, ?, NOW(), ?)
            ON DUPLICATE KEY UPDATE
                file_hash = VALUES(file_hash),
                indexed_at = VALUES(indexed_at),
                entry_count = VALUES(entry_count)
        ");
        $up->execute([$datasetId, $fileHash, $count]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('deenai index sync warning: ' . $e->getMessage() . ' file=' . $realPath);
    }
}

function deenai_parse_txt_qa_blocks(string $raw): array {
    $blocks = preg_split('/\R-{3,}\R/u', trim($raw)) ?: [];
    $entries = [];
    foreach ($blocks as $block) {
        $block = trim((string)$block);
        if ($block === '') {
            continue;
        }

        $id = '';
        $category = '';
        $source = '';
        if (preg_match('/^\s*ID:\s*(.+?)\R/im', $block, $m)) {
            $id = deenai_clean_text((string)$m[1]);
        }
        if (preg_match('/^\s*Category:\s*(.+?)\R/im', $block, $m)) {
            $category = deenai_clean_text((string)$m[1]);
        }
        if (preg_match('/^\s*Source:\s*(.+?)\s*$/im', $block, $m)) {
            $source = deenai_clean_text((string)$m[1]);
        }

        $qPos = deenai_stripos($block, 'Question:');
        $aPos = deenai_stripos($block, 'Answer:');
        if ($qPos === false || $aPos === false || (int)$aPos <= (int)$qPos) {
            continue;
        }

        $questionStart = (int)$qPos + strlen('Question:');
        $question = trim(deenai_substr($block, $questionStart, (int)$aPos - $questionStart));

        $answerStart = (int)$aPos + strlen('Answer:');
        $sourcePos = deenai_stripos($block, 'Source:', $answerStart);
        if ($sourcePos !== false && (int)$sourcePos > $answerStart) {
            $answer = trim(deenai_substr($block, $answerStart, (int)$sourcePos - $answerStart));
        } else {
            $answer = trim(deenai_substr($block, $answerStart));
        }

        if ($question === '' || $answer === '') {
            continue;
        }

        $entries[] = [
            'id' => $id,
            'category' => $category,
            'question' => $question,
            'answer' => $answer,
            'source' => $source
        ];
    }
    return $entries;
}

function deenai_collect_json_files(string $path): array {
    if (is_file($path) && strtolower(pathinfo($path, PATHINFO_EXTENSION)) === 'json') {
        return [$path];
    }
    if (!is_dir($path)) {
        return [];
    }
    $files = glob($path . DIRECTORY_SEPARATOR . '*.json') ?: [];
    sort($files, SORT_NATURAL | SORT_FLAG_CASE);
    return array_values(array_filter($files, 'is_file'));
}

function deenai_json_file_to_array(string $file): ?array {
    $raw = @file_get_contents($file);
    if ($raw === false || trim($raw) === '') {
        return null;
    }
    $data = json_decode($raw, true);
    if (is_array($data)) {
        return $data;
    }
    return null;
}

function deenai_flatten_json_strings(mixed $value): array {
    $out = [];
    $walker = function (mixed $node) use (&$walker, &$out): void {
        if (is_array($node)) {
            foreach ($node as $v) {
                $walker($v);
            }
            return;
        }
        if (is_string($node)) {
            $str = deenai_clean_text($node);
            if ($str !== '' && deenai_strlen($str) >= 20) {
                $out[] = $str;
            }
        }
    };
    $walker($value);
    return $out;
}
