<?php
declare(strict_types=1);

require_once __DIR__ . '/common.php';

function deenai_ensure_schema(PDO $pdo): void {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS datasets (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(180) NOT NULL,
            type ENUM('quran','hadith','fiqh','aqeedah','fatwa','book','story','faq','dua','adhkar','asmaulhusna') NOT NULL,
            storage_type ENUM('json','txt') NOT NULL DEFAULT 'json',
            file_path VARCHAR(500) NOT NULL,
            keywords TEXT NULL,
            description TEXT NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_datasets_type_active (type, active),
            KEY idx_datasets_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    deenai_ensure_dataset_type_enum($pdo);

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS dataset_sections (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            dataset_id INT UNSIGNED NOT NULL,
            section_title VARCHAR(180) NOT NULL,
            start_marker VARCHAR(300) NULL,
            end_marker VARCHAR(300) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_dataset_sections_dataset (dataset_id),
            CONSTRAINT fk_dataset_sections_dataset
                FOREIGN KEY (dataset_id) REFERENCES datasets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ai_provider_keys (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            provider_name ENUM('groq','gemini','openrouter','huggingface') NOT NULL,
            api_key TEXT NOT NULL,
            model_name VARCHAR(180) NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_provider_name (provider_name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ai_cache (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            cache_key CHAR(64) NOT NULL,
            response_json LONGTEXT NOT NULL,
            expires_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_ai_cache_key (cache_key),
            KEY idx_ai_cache_expires (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ai_query_logs (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT NULL,
            query_text TEXT NOT NULL,
            normalized_query TEXT NOT NULL,
            intent VARCHAR(80) NULL,
            dataset_id INT UNSIGNED NULL,
            status ENUM('success','out_of_scope','failed') NOT NULL DEFAULT 'success',
            response_time_ms INT NOT NULL DEFAULT 0,
            cache_hit TINYINT(1) NOT NULL DEFAULT 0,
            provider_used VARCHAR(40) NULL,
            extracted_items INT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_ai_logs_user_created (user_id, created_at),
            KEY idx_ai_logs_intent_created (intent, created_at),
            KEY idx_ai_logs_status_created (status, created_at),
            CONSTRAINT fk_ai_query_dataset FOREIGN KEY (dataset_id) REFERENCES datasets(id) ON DELETE SET NULL,
            CONSTRAINT fk_ai_query_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ai_provider_logs (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            query_log_id BIGINT UNSIGNED NOT NULL,
            provider_name VARCHAR(40) NOT NULL,
            model_name VARCHAR(180) NULL,
            status ENUM('success','failed') NOT NULL,
            latency_ms INT NOT NULL DEFAULT 0,
            error_message TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_ai_provider_logs_query (query_log_id),
            CONSTRAINT fk_ai_provider_log_query
                FOREIGN KEY (query_log_id) REFERENCES ai_query_logs(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ai_dataset_entries (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            dataset_id INT UNSIGNED NOT NULL,
            entry_key VARCHAR(120) NOT NULL,
            category VARCHAR(80) NULL,
            question MEDIUMTEXT NULL,
            answer LONGTEXT NULL,
            source VARCHAR(255) NULL,
            search_text LONGTEXT NULL,
            entry_hash CHAR(40) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_ai_dataset_entry (dataset_id, entry_key),
            KEY idx_ai_dataset_entries_dataset (dataset_id),
            FULLTEXT KEY ft_ai_dataset_entries (question, answer, search_text),
            CONSTRAINT fk_ai_dataset_entries_dataset
                FOREIGN KEY (dataset_id) REFERENCES datasets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ai_dataset_index_state (
            dataset_id INT UNSIGNED NOT NULL,
            file_hash CHAR(64) NOT NULL,
            indexed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            entry_count INT NOT NULL DEFAULT 0,
            PRIMARY KEY (dataset_id),
            CONSTRAINT fk_ai_dataset_index_state_dataset
                FOREIGN KEY (dataset_id) REFERENCES datasets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ai_feedback (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            query_log_id BIGINT UNSIGNED NULL,
            user_id INT NULL,
            helpful TINYINT(1) NOT NULL DEFAULT 1,
            correction_text TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_ai_feedback_query_user (query_log_id, user_id),
            KEY idx_ai_feedback_user_created (user_id, created_at),
            CONSTRAINT fk_ai_feedback_query
                FOREIGN KEY (query_log_id) REFERENCES ai_query_logs(id) ON DELETE SET NULL,
            CONSTRAINT fk_ai_feedback_user
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}

function deenai_ensure_dataset_type_enum(PDO $pdo): void {
    $required = ['quran','hadith','fiqh','aqeedah','fatwa','book','story','faq','dua','adhkar','asmaulhusna'];
    try {
        $st = $pdo->query("SHOW COLUMNS FROM datasets LIKE 'type'");
        $row = $st ? $st->fetch(PDO::FETCH_ASSOC) : null;
        if (!$row) {
            return;
        }
        $typeDef = deenai_lower((string)($row['Type'] ?? ''));
        $missing = [];
        foreach ($required as $type) {
            if (!str_contains($typeDef, "'" . $type . "'")) {
                $missing[] = $type;
            }
        }
        if ($missing) {
            $enum = "'" . implode("','", $required) . "'";
            $pdo->exec("ALTER TABLE datasets MODIFY COLUMN type ENUM($enum) NOT NULL");
        }
    } catch (Throwable $e) {
        error_log('deenai schema enum migration warning: ' . $e->getMessage());
    }
}

function deenai_seed_default_datasets(PDO $pdo): void {
    $defaults = [
        [
            'name' => 'Quran JSON Dataset',
            'type' => 'quran',
            'storage_type' => 'json',
            'file_path' => 'quranHadith/data/quran',
            'keywords' => 'quran,ayah,surah,verse,tafsir',
            'description' => 'Local Quran JSON files by surah with Arabic and English text.'
        ],
        [
            'name' => 'Hadith JSON Dataset',
            'type' => 'hadith',
            'storage_type' => 'json',
            'file_path' => 'quranHadith/data/hadith/processed',
            'keywords' => 'hadith,bukhari,muslim,tirmidhi,nawawi,sunnah',
            'description' => 'Local processed hadith collections in JSON format.'
        ],
        [
            'name' => 'Dua and Adhkar Dataset',
            'type' => 'dua',
            'storage_type' => 'json',
            'file_path' => 'tools/data/dua.json',
            'keywords' => 'dua,adhkar,azkar,supplication,protection,forgiveness,patience',
            'description' => 'Local dua and adhkar JSON dataset for guidance and remedy questions.'
        ],
        [
            'name' => '99 Names of Allah Dataset',
            'type' => 'asmaulhusna',
            'storage_type' => 'json',
            'file_path' => 'tools/data/99names.json',
            'keywords' => '99 names,asmaul husna,names of Allah,attributes',
            'description' => 'Local JSON dataset for Asma ul Husna (99 Names of Allah).'
        ]
    ];

    $islamqaRelative = 'datasets_import/islamqa_en.txt';
    $islamqaAbsolute = deenai_project_root() . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $islamqaRelative);
    if (is_file($islamqaAbsolute)) {
        $defaults[] = [
            'name' => 'IslamQA English TXT Dataset',
            'type' => 'fatwa',
            'storage_type' => 'txt',
            'file_path' => $islamqaRelative,
            'keywords' => 'fatwa,fiqh,qa,islamqa,prayer,fasting,marriage,sins',
            'description' => 'Structured QA text dataset imported from IslamQA source.'
        ];
    }

    $existsStmt = $pdo->prepare('SELECT id FROM datasets WHERE name = ? LIMIT 1');
    $insertStmt = $pdo->prepare('
        INSERT INTO datasets (name, type, storage_type, file_path, keywords, description, active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, 1, NOW(), NOW())
    ');

    foreach ($defaults as $row) {
        $existsStmt->execute([$row['name']]);
        if ($existsStmt->fetch(PDO::FETCH_ASSOC)) {
            continue;
        }
        $insertStmt->execute([
            $row['name'],
            $row['type'],
            $row['storage_type'],
            $row['file_path'],
            $row['keywords'],
            $row['description']
        ]);
    }
}

function deenai_get_provider_config(PDO $pdo): array {
    $st = $pdo->query("
        SELECT provider_name, api_key, model_name, active
        FROM ai_provider_keys
        ORDER BY FIELD(provider_name, 'groq', 'gemini', 'openrouter', 'huggingface')
    ");
    $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $out = [];
    foreach ($rows as $row) {
        $name = strtolower((string)($row['provider_name'] ?? ''));
        if ($name === '') {
            continue;
        }
        $out[$name] = [
            'api_key' => (string)($row['api_key'] ?? ''),
            'model_name' => (string)($row['model_name'] ?? ''),
            'active' => (int)($row['active'] ?? 0) === 1
        ];
    }
    return $out;
}

function deenai_cache_get(PDO $pdo, string $cacheKey): ?array {
    $st = $pdo->prepare("
        SELECT response_json
        FROM ai_cache
        WHERE cache_key = ?
          AND expires_at > NOW()
        LIMIT 1
    ");
    $st->execute([$cacheKey]);
    $raw = $st->fetchColumn();
    if (!is_string($raw) || trim($raw) === '') {
        return null;
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : null;
}

function deenai_cache_set(PDO $pdo, string $cacheKey, array $response, int $ttlSeconds = 21600): void {
    $ttlSeconds = max(300, min(86400, $ttlSeconds));
    $json = json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) {
        return;
    }
    $st = $pdo->prepare("
        INSERT INTO ai_cache (cache_key, response_json, expires_at, created_at)
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND), NOW())
        ON DUPLICATE KEY UPDATE
            response_json = VALUES(response_json),
            expires_at = VALUES(expires_at)
    ");
    $st->execute([$cacheKey, $json, $ttlSeconds]);
}

function deenai_log_query(
    PDO $pdo,
    int $userId,
    string $queryText,
    string $normalizedQuery,
    ?string $intent,
    ?int $datasetId,
    string $status,
    int $responseMs,
    bool $cacheHit,
    ?string $providerUsed,
    int $extractedItems
): int {
    $st = $pdo->prepare("
        INSERT INTO ai_query_logs (
            user_id, query_text, normalized_query, intent, dataset_id, status,
            response_time_ms, cache_hit, provider_used, extracted_items, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    $st->execute([
        $userId > 0 ? $userId : null,
        $queryText,
        $normalizedQuery,
        $intent,
        $datasetId,
        $status,
        max(0, $responseMs),
        $cacheHit ? 1 : 0,
        $providerUsed,
        max(0, $extractedItems)
    ]);
    return (int)$pdo->lastInsertId();
}

function deenai_log_provider_attempt(
    PDO $pdo,
    int $queryLogId,
    string $providerName,
    ?string $modelName,
    string $status,
    int $latencyMs,
    ?string $errorMessage = null
): void {
    if ($queryLogId <= 0) {
        return;
    }
    $st = $pdo->prepare("
        INSERT INTO ai_provider_logs (
            query_log_id, provider_name, model_name, status, latency_ms, error_message, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    $st->execute([
        $queryLogId,
        substr($providerName, 0, 40),
        $modelName !== null ? substr($modelName, 0, 180) : null,
        $status === 'success' ? 'success' : 'failed',
        max(0, $latencyMs),
        $errorMessage
    ]);
}

function deenai_save_feedback(
    PDO $pdo,
    int $userId,
    int $queryLogId,
    bool $helpful,
    ?string $correctionText = null
): void {
    $queryLogId = max(0, $queryLogId);
    if ($queryLogId <= 0) {
        return;
    }

    $correctionText = $correctionText !== null ? deenai_clean_text($correctionText) : null;
    if ($correctionText !== null && $correctionText !== '') {
        if (deenai_strlen($correctionText) > 2500) {
            $correctionText = deenai_substr($correctionText, 0, 2500);
        }
    } else {
        $correctionText = null;
    }

    $st = $pdo->prepare("
        INSERT INTO ai_feedback (query_log_id, user_id, helpful, correction_text, created_at, updated_at)
        VALUES (?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            helpful = VALUES(helpful),
            correction_text = VALUES(correction_text),
            updated_at = NOW()
    ");
    $st->execute([
        $queryLogId,
        $userId > 0 ? $userId : null,
        $helpful ? 1 : 0,
        $correctionText
    ]);
}
